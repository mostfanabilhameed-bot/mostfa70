import { createInsertSchema } from "drizzle-zod";
import {
  date,
  integer,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const userRoleEnum = pgEnum("user_role", [
  "pending",
  "super_admin",
  "prosecutor",
  "employee",
  "department_manager",
]);

export const transactionStatusEnum = pgEnum("transaction_status", [
  "registered",
  "awaiting_direction",
  "in_review",
  "directive_draft",
  "rejected",
  "directed",
  "awaiting_transcription",
  "awaiting_referral",
  "referred",
  "administratively_closed",
  "administratively_cancelled",
]);

export const confidentialityEnum = pgEnum("confidentiality", [
  "normal",
  "confidential",
  "secret",
]);

export const urgencyEnum = pgEnum("urgency", ["normal", "urgent", "immediate"]);

export const userProfilesTable = pgTable("user_profiles", {
  id: uuid("id").primaryKey().defaultRandom(),
  clerkUserId: text("clerk_user_id").notNull().unique(),
  displayName: text("display_name").notNull(),
  role: userRoleEnum("role").notNull().default("pending"),
  department: text("department"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const annualSequencesTable = pgTable("annual_sequences", {
  year: integer("year").primaryKey(),
  lastNumber: integer("last_number").notNull().default(0),
});

export const inboundTransactionsTable = pgTable(
  "inbound_transactions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    inboundNumber: integer("inbound_number").notNull(),
    year: integer("year").notNull(),
    status: transactionStatusEnum("status").notNull().default("registered"),
    subject: text("subject").notNull(),
    senderName: text("sender_name").notNull(),
    source: text("source").notNull(),
    receivedDate: date("received_date", { mode: "string" }).notNull(),
    registeredAt: timestamp("registered_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    confidentiality: confidentialityEnum("confidentiality")
      .notNull()
      .default("normal"),
    urgency: urgencyEnum("urgency").notNull().default("normal"),
    notes: text("notes"),
    attachmentPath: text("attachment_path").notNull(),
    attachmentName: text("attachment_name").notNull(),
    attachmentContentType: text("attachment_content_type").notNull(),
    attachmentSize: integer("attachment_size").notNull(),
    attachmentSha256: text("attachment_sha256").notNull(),
    directiveText: text("directive_text"),
    directiveDraftText: text("directive_draft_text"),
    rejectionReason: text("rejection_reason"),
    transcription: text("transcription"),
    referralDestination: text("referral_destination"),
    createdBy: text("created_by").notNull(),
    createdByName: text("created_by_name").notNull(),
    department: text("department"),
    version: integer("version").notNull().default(1),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    uniqueIndex("inbound_transactions_year_number_idx").on(
      table.year,
      table.inboundNumber,
    ),
    uniqueIndex("inbound_transactions_attachment_path_idx").on(
      table.attachmentPath,
    ),
  ],
);

export const pendingUploadsTable = pgTable("pending_uploads", {
  objectPath: text("object_path").primaryKey(),
  ownerUserId: text("owner_user_id").notNull(),
  fileName: text("file_name").notNull(),
  contentType: text("content_type").notNull(),
  size: integer("size").notNull(),
  claimedAt: timestamp("claimed_at", { withTimezone: true }),
  transactionId: uuid("transaction_id"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const timelineEventsTable = pgTable("timeline_events", {
  id: uuid("id").primaryKey().defaultRandom(),
  transactionId: uuid("transaction_id")
    .notNull()
    .references(() => inboundTransactionsTable.id, { onDelete: "restrict" }),
  eventType: text("event_type").notNull(),
  description: text("description").notNull(),
  actorUserId: text("actor_user_id").notNull(),
  actorName: text("actor_name").notNull(),
  previousValue: text("previous_value"),
  newValue: text("new_value"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const auditLogsTable = pgTable("audit_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  actorUserId: text("actor_user_id").notNull(),
  action: text("action").notNull(),
  entityType: text("entity_type").notNull(),
  entityId: text("entity_id").notNull(),
  previousValue: text("previous_value"),
  newValue: text("new_value"),
  outcome: text("outcome").notNull().default("success"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const insertUserProfileSchema = createInsertSchema(userProfilesTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const insertInboundTransactionSchema = createInsertSchema(
  inboundTransactionsTable,
).omit({
  id: true,
  registeredAt: true,
  createdAt: true,
  updatedAt: true,
});
export const insertTimelineEventSchema = createInsertSchema(
  timelineEventsTable,
).omit({
  id: true,
  createdAt: true,
});
export const insertAuditLogSchema = createInsertSchema(auditLogsTable).omit({
  id: true,
  createdAt: true,
});

export type UserRole = (typeof userRoleEnum.enumValues)[number];
export type TransactionStatus =
  (typeof transactionStatusEnum.enumValues)[number];
export type Confidentiality =
  (typeof confidentialityEnum.enumValues)[number];
export type Urgency = (typeof urgencyEnum.enumValues)[number];
export type UserProfile = typeof userProfilesTable.$inferSelect;
export type InsertUserProfile = z.infer<typeof insertUserProfileSchema>;
export type InboundTransaction =
  typeof inboundTransactionsTable.$inferSelect;
export type InsertInboundTransaction = z.infer<
  typeof insertInboundTransactionSchema
>;
export type TimelineEvent = typeof timelineEventsTable.$inferSelect;
export type InsertTimelineEvent = z.infer<typeof insertTimelineEventSchema>;
export type AuditLog = typeof auditLogsTable.$inferSelect;
export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;
