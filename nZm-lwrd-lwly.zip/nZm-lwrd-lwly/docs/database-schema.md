# مخطط PostgreSQL المقترح

**الحالة:** مسودة تصميم — لم تُنفّذ أي ترحيلات.  
**المصدر:** مخطط PostgreSQL الحالي في التطوير ووثيقة متطلبات نظام الوارد.  
**ملاحظة:** هذه وثيقة هدف مقترح وليست وصفاً للجداول المنشورة حالياً.

## 1. مبادئ التصميم

- PostgreSQL هو مصدر الحقيقة لكل البيانات التشغيلية. تخزن الملفات خارج قاعدة البيانات في تخزين خاص؛ تحفظ المسارات والبصمات والبيانات الوصفية في PostgreSQL.
- المعرفات الداخلية UUID. يحتفظ النظام بمعرّف Clerk الخارجي كنص فريد، ولا يستخدمه بديلاً عن العلاقات الداخلية.
- لا حذف مادي للمعاملة أو لتاريخها. تستخدم الحالات الإدارية، مع سبب وفاعل ووقت، بدلاً من حذف السجل.
- لكل سنة تسلسل مستقل، مع قيد فريد على `(year, inbound_number)` وتخصيص ذري داخل الخادم.
- كل تغيير يؤثر في سير العمل يسجل حدثاً زمنياً وسجل تدقيق ضمن المعاملة نفسها.
- تحفظ نسخ تعريفات النماذج والقوائم التي استُخدمت عند التسجيل، كي لا يغير تعديل الإعدادات معنى السجلات التاريخية.
- لا يُعتمد JSONB لتخزين حقول تشغيلية متكررة أو قابلة للعلاقات. يقتصر على القيم الديناميكية، تكوين الحقول، بيانات التأشير، ولقطات التغيير.

## 2. المخطط الحالي الذي تمت معاينته

قاعدة التطوير تحتوي حالياً على هذه الجداول الستة:

| الجدول الحالي | ملاحظات المخطط الحالي |
| --- | --- |
| `user_profiles` | يربط `clerk_user_id` بالاسم، ودور ثابت، وقسم نصي. |
| `annual_sequences` | `year` مفتاح أساسي و`last_number` للترقيم. |
| `inbound_transactions` | بيانات المعاملة والتوجيه في صف واحد؛ المرفق محفوظ كحقول مسار واسم ونوع وحجم وبصمة. |
| `pending_uploads` | يربط مسار الرفع بحساب المالك وحالة استخدامه. |
| `timeline_events` | أحداث مرتبطة بالمعاملة وفاعلها. |
| `audit_logs` | سجل إجراءات إداري عام. |

المقترح التالي يطبع العلاقات ويضيف دعم الأدوار الديناميكية وإصدارات التوجيه والمرفقات والحقول. لا تُحذف الأعمدة الحالية قبل ترحيل البيانات والتحقق من عدد السجلات والعلاقات والبصمات.

## 3. القيم المرجعية والحالات

### حالات المعاملة

حالات ثابتة في عقد API ومخطط قاعدة البيانات، ولا يمكن لمسؤول النظام إنشاء انتقالات اعتباطية:

`registration_draft`, `registered`, `awaiting_direction`, `in_review`, `directive_draft`, `rejected`, `directed`, `awaiting_transcription`, `awaiting_referral`, `referred`, `administratively_closed`, `administratively_cancelled`.

خريطة الانتقال والتحقق من دور المستخدم في API. حالة `registration_draft` لا تحجز رقماً؛ يحجز الرقم عند التسجيل المكتمل فقط. بعد حجز الرقم لا يعاد استخدامه حتى عند الإلغاء.

### درجات السرية والاستعجال

- `confidentiality_levels`: قائمة علائقية بمفتاح ثابت واسم عربي وترتيب/درجة سرية وحالة تفعيل. تُربط صلاحيات الرؤية والتنزيل والطباعة بكل مستوى.
- الاستعجال يستخدم قائمة مرجعية قابلة للإدارة، مع قيم أساسية أولية مثل عادي وعاجل وفوري.
- نوع الوارد، جهة الورود، وجهة الإحالة قوائم مرجعية؛ لا تُحذف قيمة استُخدمت تاريخياً، بل توقف وتبقى لقطتها في السجل.

## 4. الكيانات والعلاقات

```mermaid
erDiagram
  departments ||--o{ user_profiles : includes
  user_profiles ||--o{ user_role_assignments : receives
  roles ||--o{ user_role_assignments : grants
  roles ||--o{ role_permissions : has
  permissions ||--o{ role_permissions : assigned
  roles ||--o{ role_confidentiality_permissions : allows
  confidentiality_levels ||--o{ role_confidentiality_permissions : scoped
  annual_sequences ||--o{ inbound_transactions : numbers
  departments ||--o{ inbound_transactions : owns
  user_profiles ||--o{ inbound_transactions : registers
  inbound_transactions ||--o{ transaction_attachments : contains
  inbound_transactions ||--o{ directive_versions : has
  directive_versions ||--o| transaction_attachments : produces
  inbound_transactions ||--o{ transaction_notes : has
  transaction_notes ||--o{ note_replies : receives
  inbound_transactions ||--o{ modification_requests : has
  inbound_transactions ||--o{ timeline_events : records
  inbound_transactions ||--o{ transaction_field_values : stores
  form_schema_versions ||--o{ inbound_transactions : snapshots
  form_schema_versions ||--o{ form_schema_fields : defines
  field_definition_versions ||--o{ form_schema_fields : included
  field_definition_versions ||--o{ transaction_field_values : snapshots
  reference_lists ||--o{ reference_list_items : contains
  user_profiles ||--o{ user_notifications : receives
```

كل الصفوف الحساسة مرتبطة بمعرّف مستخدم داخلي. في `audit_logs` يمكن أن يكون الفاعل فارغاً للأحداث النظامية، مع تسجيل هوية الطلب أو خدمة النظام.

## 5. تعريف الجداول المقترح

`UUID` هو المفتاح الأساسي الافتراضي، و`TIMESTAMPTZ` لكل وقت فعلي. الحقول المذكورة أدناه هي الهيكل الأساسي؛ تفاصيل قيود الإدخال ورسائل API تُحدد في OpenAPI/Zod.

### الهوية والأقسام والصلاحيات

| الجدول | الحقول الأساسية والعلاقات |
| --- | --- |
| `departments` | `id`, `code`, `name_ar`, `parent_id` ذاتي اختياري، `is_active`, `created_at`, `updated_at`. قيد فريد على الرمز، ومؤشر على `parent_id`. |
| `user_profiles` | `id`, `identity_provider`, `identity_subject`, `display_name`, `department_id`, `is_active`, `created_at`, `updated_at`. قيد فريد على `(identity_provider, identity_subject)`. لا تخزن كلمة مرور أو رمز جلسة. |
| `roles` | `id`, `role_key` فريد، `name_ar`, `is_system_role`, `is_active`, `created_at`. أدوار النظام الأساسية قابلة للتخصيص بالصلاحيات لا بالتلاعب بمعرفاتها. |
| `permissions` | `id`, `permission_key` فريد، `resource`, `action`, `name_ar`, `description_ar`. تتضمن صلاحيات العرض والتسجيل والتعديل والتوجيه والاعتماد وطلبات التعديل والطباعة والتصدير والنسخ. |
| `role_permissions` | مفتاح مركب `(role_id, permission_id)`, مع `conditions_json` اختياري لقواعد إضافية. |
| `user_role_assignments` | `id`, `user_id`, `role_id`, `scope_type` (`global`, `department`, `own`, `assigned`), `scope_department_id`, `granted_by`, `granted_at`, `revoked_by`, `revoked_at`. مؤشر فريد جزئي يمنع تكرار المنحة النشطة نفسها. |
| `confidentiality_levels` | `id`, `level_key` فريد، `name_ar`, `rank`, `is_active`. لا تخفض السرية بأثر رجعي بتعديل تعريف المستوى. |
| `role_confidentiality_permissions` | مفتاح `(role_id, confidentiality_level_id)` وأعلام مستقلة `can_view`, `can_download`, `can_print`, `can_export`. |

الدور والسرية ونطاق القسم شروط متراكبة؛ نجاح شرط الدور لا يلغي شرط السرية أو ملكية المعاملة. كل محاولة وصول مرفوضة تسجل دون تضمين أسرار أو محتوى غير لازم.

### القوائم والنماذج الديناميكية

| الجدول | الحقول الأساسية والعلاقات |
| --- | --- |
| `reference_lists` | `id`, `list_key` فريد، `name_ar`, `is_active`, `created_by`, `created_at`. |
| `reference_list_items` | `id`, `list_id`, `item_code`, `label_ar`, `parent_item_id`, `sort_order`, `is_active`, `valid_from`, `valid_to`. قيد فريد على `(list_id, item_code)`؛ القيمة المستعملة لا تحذف. |
| `field_definitions` | `id`, `field_key` فريد ومستقر، `created_at`. يمثل هوية الحقل المستمرة عبر نسخه. |
| `field_definition_versions` | `id`, `field_definition_id`, `version_no`, `field_type`, `label_ar`, `required`, `searchable`, `sensitive`, `validation_json`, `access_policy_json`, `is_active`, `created_by`, `created_at`. قيد فريد `(field_definition_id, version_no)`. التعديل ينشئ نسخة جديدة. |
| `field_options` | `id`, `field_definition_version_id`, `option_code`, `label_ar`, `sort_order`, `is_active`. قيد فريد `(field_definition_version_id, option_code)`. |
| `form_schema_versions` | `id`, `schema_key`, `version_no`, `status`, `created_by`, `created_at`, `activated_at`. قيد فريد `(schema_key, version_no)`. |
| `form_schema_fields` | مفتاح `(form_schema_version_id, field_definition_version_id)`, مع `sort_order`. يحدد الحقول والنسخ الظاهرة في نموذج تسجيل محدد. |
| `transaction_field_values` | مفتاح مركب `(transaction_id, field_definition_version_id)`, `value_json`, `display_snapshot`, `created_at`. تحفظ لقطة العرض والقيمة المستخدمة تاريخياً، مع فهارس انتقائية للحقول المسموح البحث فيها. |
| `system_settings` | `setting_key` مفتاح، `value_json`, `version_no`, `updated_by`, `updated_at`. التغييرات الإدارية تُدقق وتُتحقق من مخطط الإعداد. |

تُستخدم JSONB للقيم المتغيرة، لا لتعريف صلاحية الخادم؛ إذ يحدد كل إصدار الحقول المسموحة وقواعدها، ويعيد الخادم التحقق منها قبل الحفظ. تُضاف الخيارات الجديدة كصفوف جديدة ولا يغير تعديل التسمية معنى القيم التاريخية.

### التسلسل والمعاملات والمرفقات

| الجدول | الحقول الأساسية والعلاقات |
| --- | --- |
| `annual_sequences` | `year` مفتاح أساسي، `last_number` عدد موجب. التخصيص ذري بـ`INSERT ... ON CONFLICT ... RETURNING` داخل الخادم؛ لا يحسب الرقم في الهاتف أو الويب. |
| `inbound_transactions` | `id`, `year`, `inbound_number`, `status`, `received_date DATE`, `registered_at`, `source_item_id`, `type_item_id`, `subject`, `sender_name`, `confidentiality_level_id`, `urgency_item_id`, `department_id`, `registered_by`, `assigned_to`, `form_schema_version_id`, `version_no`, `rejection_reason`, `transcription`, `referral_item_id`, `closed_at/by/reason`, `cancelled_at/by/reason`, `created_at`, `updated_at`. |
| `pending_uploads` | `object_path` مفتاح، `owner_user_id`, `file_name`, `declared_content_type`, `verified_content_type`, `size_bytes`, `sha256`, `expires_at`, `claimed_at`, `transaction_id`, `created_at`. المسار غير القابل لإعادة الاستخدام يربط الرفع بحساب مالكه. |
| `transaction_attachments` | `id`, `transaction_id`, `attachment_kind` (`original`, `working_pdf`, `approved_pdf`), `object_path` فريد، `file_name`, `content_type`, `size_bytes`, `sha256`, `uploaded_by`, `created_at`, `retention_delete_at`, `deleted_at`, `deletion_reason`. قيد فريد جزئي يسمح بأصل واحد فقط للمعاملة؛ النسخة المعتمدة مرتبطة بإصدار توجيه. |
| `directive_versions` | `id`, `transaction_id`, `version_no`, `status` (`draft`, `approved`, `superseded`), `directive_text`, `annotations_json`, `source_attachment_sha256`, `expected_transaction_version`, `created_by`, `created_at`, `approved_by`, `approved_at`, `approved_pdf_attachment_id`, `approved_pdf_sha256`. قيد فريد `(transaction_id, version_no)`. النسخة المعتمدة غير قابلة للتعديل؛ يصدر تعديل لاحق نسخة جديدة. |

قيود `inbound_transactions`:

- قيد فريد `(year, inbound_number)`، و`inbound_number > 0`.
- مفاتيح خارجية إلى المستخدمين والأقسام والقوائم ونسخة النموذج، مع `ON DELETE RESTRICT` للبيانات التاريخية.
- `version_no` موجب للتحديث التفاؤلي؛ لا يحفظ تعديل إلا إذا طابق الإصدار الذي قرأه العميل.
- لا يقبل API حالة أو هوية منفذ أو مالك أو مسار تخزين من العميل كحقائق موثوقة؛ يشتقها ويتحقق منها على الخادم.

الرفع المباشر لا يدخل الملف إلى PostgreSQL. قبل ربطه بالمعاملة، يتحقق API من المالك والانتهاء والحجم وMagic Bytes والبصمة، ثم يربطه مرة واحدة. كل بث أو تنزيل يعيد فحص صلاحية المستخدم والمعاملة ودرجة السرية.

### الملاحظات والتعديلات والتاريخ

| الجدول | الحقول الأساسية والعلاقات |
| --- | --- |
| `transaction_notes` | `id`, `transaction_id`, `note_type` (`internal`, `rejection`, `follow_up`), `body`, `visibility_policy`, `created_by`, `created_at`, `resolved_at`. الملاحظة لا تعني الرفض إلا إذا نفذ إجراء رفض صريح. |
| `note_replies` | `id`, `note_id`, `body`, `created_by`, `created_at`; تمنع الردود غير المصرح بها وفق نطاق المعاملة. |
| `modification_requests` | `id`, `transaction_id`, `field_definition_version_id`, `old_value_json`, `requested_value_json`, `reason`, `status` (`pending`, `approved`, `rejected`, `cancelled`), `requested_by`, `reviewed_by`, `decision_reason`, `created_at`, `reviewed_at`. الطلب لحقل واحد؛ موافقته تحدث ذلك الحقل فقط داخل معاملة ذرية. |
| `timeline_events` | `id`, `transaction_id`, `event_type`, `description`, `actor_user_id`, `previous_status`, `new_status`, `details_json`, `request_id`, `created_at`. سجل زمني للمعاملة، لا يستخدم بديلاً عن `audit_logs`. |
| `audit_logs` | `id`, `actor_user_id`, `action`, `entity_type`, `entity_id`, `previous_data_json`, `new_data_json`, `reason`, `outcome`, `request_id`, `created_at`. يكتب عبر مسارات موثوقة ويمنع تطبيقياً تحديثه أو حذفه. |

وجود `audit_logs` داخل PostgreSQL وحده لا يمنع مالك قاعدة البيانات من العبث. لذلك يُنشأ تصدير دوري مجمع مع SHA-256 إلى وجهة منفصلة مقيدة الصلاحيات. لا توصف هذه الآلية كتوقيع قانوني أو ضمان عدم عبث مطلق.

### التنبيهات والنسخ والاستعادة

| الجدول | الحقول الأساسية والعلاقات |
| --- | --- |
| `user_notifications` | `id`, `user_id`, `event_type`, `entity_id`, `message_ar`, `created_at`, `read_at`, `delivery_status`. لا يتضمن نص المستند السري في الإشعار. |
| `backup_runs` | `id`, `started_at`, `completed_at`, `status`, `database_snapshot_ref`, `manifest_path`, `archive_path`, `sha256`, `encrypted`, `verification_status`, `retention_until`, `error_code`. تخزن نسخة manifest خارج قاعدة التطبيق لتبقى متاحة عند فقدها. |
| `restore_tests` | `id`, `backup_run_id`, `started_at`, `completed_at`, `isolated_target_ref`, `status`, `database_check_summary`, `attachment_check_summary`, `verified_by`. الاختبار لا يكتب إلى الإنتاج ولا ينسخ بياناته إلى جهاز غير مصرح. |

يجب أن تحدد سياسة النسخ الوجهة الخارجية وفترة الاحتفاظ ومفتاح التشفير ومسؤول الاستعادة قبل اعتبار النظام جاهزاً. لا تنفذ هذه الوثيقة إنشاء موارد أو نسخ فعلية.

## 6. القيود والفهارس المطلوبة

- `UNIQUE (year, inbound_number)` على المعاملات.
- `PRIMARY KEY (year)` على التسلسل السنوي، مع تحديث ذري؛ أرقام الحجز الفاشلة قد تترك فجوة ولا يعاد استخدامها.
- `UNIQUE (object_path)` للمرفق، وفريد جزئي لـ`attachment_kind = 'original'` لكل معاملة.
- `UNIQUE (transaction_id, version_no)` لإصدارات التوجيه.
- فهارس مركبة على معاملات `(status, updated_at)`, `(department_id, status, updated_at)`, `(registered_by, registered_at)`, `(year, inbound_number)`، ومؤشر على `referral_item_id`.
- فهارس على أحداث المعاملة `(transaction_id, created_at)` وعلى التدقيق `(entity_type, entity_id, created_at)` و`(actor_user_id, created_at)`.
- فهارس على الطلبات `(status, created_at)` و`(department_id, status)`، وعلى مهام الإشعارات غير المقروءة.
- البحث النصي العربي يعتمد فهرسة مناسبة بعد التحقق من امتدادات PostgreSQL المتاحة؛ لا يُعتمد على `ILIKE` واسع غير محدود أو على افتراض توفر امتداد.
- القيود والفهارس الجديدة تُختبر على بيانات التطوير قبل اعتماد migration. لا تستخدم `DROP` أو حذفاً جماعياً لإصلاح تعارضات المخطط.

## 7. قواعد ذرية وثوابت البيانات

1. التسجيل النهائي يحجز الرقم ويربط الرفع وينشئ المعاملة وحدثها وسجل تدقيقها ضمن عملية ذرية. لا يظهر رقم غير مرتبط بمعاملة ناجحة؛ وإذا اختيرت سياسة حجز مسبق، لا يعاد الرقم المحجوز.
2. كل انتقال حالة يتحقق من الحالة السابقة والدور والنطاق، ويكتب الحالة والـtimeline والـaudit في معاملة PostgreSQL واحدة.
3. تحديث المسودة وبيانات المعاملة يتحقق من `version_no`; التعارض يعيد `409` مع طلب إعادة التحميل ولا يطمس آخر حفظ.
4. رفض المعاملة يتطلب سبباً؛ الاعتماد يتطلب مسودة محفوظة. الاعتماد ينشئ نسخة PDF ثابتة مرتبطة ببصمتها.
5. موافقة طلب تعديل تغير الحقل الموافق عليه فقط وتحفظ القيمة السابقة والجديدة؛ لا يُعدل نص التوجيه المعتمد.
6. الإغلاق والإلغاء وإعادة الفتح تتطلب سبباً وتسجل الحالة السابقة والجديدة؛ لا تحذف المعاملة.
7. حذف الأصل المؤجل عملية قابلة لإعادة المحاولة بأمان، لها حدث تدقيق ونتيجة؛ لا تُفعّل قبل حسم احتفاظ النسخ الاحتياطية.

## 8. خطة ترحيل من المخطط الحالي

هذه خطة مقترحة فقط، ولا تنفذ قبل اعتماد المخطط:

1. إضافة جداول الأقسام والأدوار والصلاحيات والقوائم وإصدارات النماذج والمرفقات والتوجيهات بصورة إضافية.
2. إنشاء ملف مستخدم داخلي وربط `user_profiles.clerk_user_id` بالمعرّف الخارجي، مع تحويل القسم النصي إلى `department_id` بعد مطابقة القيم.
3. نسخ حقول الملف الحالية من `inbound_transactions` إلى `transaction_attachments` والتحقق من مطابقة المسار والنوع والحجم والبصمة قبل التبديل.
4. تحويل المالك والفاعل النصي إلى مفاتيح المستخدم الداخلية بعد فحص وجود ملف لكل معرّف؛ أي قيمة يتعذر حلها توقف الترحيل وتبقى محفوظة للتحقيق.
5. تشغيل تحقق عدد الصفوف، القيود الفريدة، العلاقات، عينة بصمات الملفات، وتقارير الحالات قبل تحويل API.
6. تحديث العملاء والخادم عبر عقد OpenAPI ثم إزالة الأعمدة القديمة في ترحيل مستقل لاحق فقط بعد نجاح الاختبارات والموافقة.

إنتاج Replit PostgreSQL له مسار نشر منفصل عن قاعدة التطوير؛ تُراجع فروق المخطط وعمليات إعادة التسمية في واجهة النشر. لا يضاف DDL عند إقلاع الخادم، ولا ينفذ هذا التصميم أي ترحيل إنتاجي.

## 9. مسائل تحتاج قراراً

1. من يرى كل درجة سرية، ومن يملك التنزيل والطباعة والتصدير لكل درجة؟
2. حذف الأصل بعد سبعة أيام: هل يشمل النسخ الاحتياطية؟ وما مدة الاحتفاظ بها؟ لا يمكن تشغيل حذف آمن قبل الإجابة.
3. عند رفع صورة: هل تحفظ الصورة الأصلية مؤقتاً سبعة أيام مع PDF محول، أم يتحول الملف إلى PDF قبل تسجيله مع إبقاء البصمة والنوع الأصليين؟
4. هل توجد متطلبات رقمية/قانونية محددة للتوقيع أم أن PDF المؤشر عليه المرئي سجل توجيه فقط؟
5. هل تكون صلاحية النائب العام على جميع الأقسام والسرية أو ضمن نطاق يحدده مالك النظام؟
6. من يملك مفاتيح النسخ الاحتياطي والوجهة الخارجية، ومن يجيز اختبار الاستعادة؟

حتى اعتماد هذه القرارات، لا تتغير الجداول الحالية ولا تنفذ إجراءات حذف أو نشر.
