import { type ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ClerkProvider, Show, SignIn, SignUp, useAuth, useClerk } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { arSA } from '@clerk/localizations';
import { Route, Switch, Redirect, Link, useLocation, Router as WouterRouter } from 'wouter';
import {
  Activity, ArrowLeft, ArrowUpRight, BadgeCheck, Bell, BookOpen,
  Check, ChevronDown, ChevronLeft, ClipboardList, Clock3, FileCheck2, FilePlus2,
  FileText, FolderOpen, Gauge, History, Inbox, Landmark, LockKeyhole, LogOut,
  Menu, Paperclip, Search, ShieldAlert, ShieldCheck, SlidersHorizontal,
  UserCog, Users, X,
} from 'lucide-react';
import {
  getGetCurrentUserQueryKey, getGetDashboardSummaryQueryKey, getGetTransactionQueryKey,
  getGetTransactionTimelineQueryKey, getListTransactionsQueryKey, getListUsersQueryKey,
  useApproveDirective, useCreateTransaction, useDispatchTransaction, useGetCurrentUser,
  useGetDashboardSummary, useGetTransaction, useGetTransactionTimeline, useListTransactions,
  useListUsers, useRejectTransaction, useRequestUploadUrl, useSaveDirectiveDraft,
  useSaveReferral, useSubmitTransaction, useUpdateUserRole,
  type Attachment, type Confidentiality, type Transaction, type TransactionStatus,
  type UserProfile, type UserRole, type Urgency,
} from '@workspace/api-client-react';
import { useForm } from 'react-hook-form';
import {
  Form, FormControl, FormField, FormItem, FormLabel, FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

function stripBase(path: string) {
  return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || '/' : path;
}

const roleText: Record<UserRole, string> = {
  pending: 'بانتظار تفعيل الصلاحية',
  super_admin: 'مدير النظام',
  prosecutor: 'المدعي العام',
  employee: 'موظف',
  department_manager: 'مدير قسم',
};
const statusText: Record<TransactionStatus, string> = {
  registered: 'مسجل',
  awaiting_direction: 'بانتظار التوجيه',
  in_review: 'قيد المراجعة',
  directive_draft: 'مسودة توجيه',
  rejected: 'مرفوض',
  directed: 'تم التوجيه',
  awaiting_transcription: 'بانتظار التفريغ',
  awaiting_referral: 'بانتظار الإحالة',
  referred: 'تمت الإحالة',
  administratively_closed: 'مغلق إدارياً',
  administratively_cancelled: 'ملغى إدارياً',
};
const confidentialityText: Record<Confidentiality, string> = { normal: 'عادي', confidential: 'سري', secret: 'سري للغاية' };
const urgencyText: Record<Urgency, string> = { normal: 'عادي', urgent: 'عاجل', immediate: 'فوري' };
const statusStyle: Record<TransactionStatus, string> = {
  registered: 'bg-stone-100 text-stone-700',
  awaiting_direction: 'bg-amber-50 text-amber-800',
  in_review: 'bg-orange-50 text-orange-800',
  directive_draft: 'bg-rose-50 text-rose-800',
  rejected: 'bg-red-50 text-red-800',
  directed: 'bg-emerald-50 text-emerald-800',
  awaiting_transcription: 'bg-blue-50 text-blue-800',
  awaiting_referral: 'bg-cyan-50 text-cyan-800',
  referred: 'bg-emerald-100 text-emerald-900',
  administratively_closed: 'bg-stone-100 text-stone-700',
  administratively_cancelled: 'bg-stone-100 text-stone-700',
};

function formatDate(value?: string) {
  if (!value) return '—';
  return new Intl.DateTimeFormat('ar', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value));
}
function formatDay(value?: string) {
  if (!value) return '—';
  return new Intl.DateTimeFormat('ar', { dateStyle: 'medium' }).format(new Date(value));
}
function errorMessage(error: unknown) {
  return error instanceof Error ? error.message : 'تعذر إتمام الطلب. يرجى المحاولة مجدداً.';
}

function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-3" data-testid="brand-wordmark">
      <div className="grid h-10 w-10 place-items-center border border-[#C5A059]/50 bg-[#4A0E17] text-[#D4AF37]" aria-hidden="true">
        <span className="flex h-5 items-end gap-[3px]">
          <i className="h-3 w-[3px] bg-current" /><i className="h-5 w-[3px] bg-current" /><i className="h-4 w-[3px] bg-current" />
        </span>
      </div>
      {!compact && <div className="leading-tight">
        <div className="text-sm font-bold tracking-wide">نظام الوارد الأولي</div>
        <div className="mt-1 text-[10px] text-[#eadfcf]/70">إدارة المعاملات الواردة</div>
      </div>}
    </div>
  );
}

function HomePage() {
  return (
    <main className="relative min-h-[100dvh] overflow-hidden bg-[#f5f1e9] text-[#4A0E17]" dir="rtl" data-testid="page-home">
      <div className="absolute inset-y-0 left-0 hidden w-[35%] border-r border-[#d9ccba] bg-[#eee7da] lg:block" />
      <header className="relative mx-auto flex max-w-7xl items-center justify-between px-5 py-5 md:px-10">
        <Brand />
        <nav className="flex items-center gap-2">
          <Link href="/sign-in" className="rounded-md px-4 py-2 text-sm font-semibold text-[#58141E] hover:bg-[#58141E]/5" data-testid="link-sign-in">تسجيل الدخول</Link>
          <Link href="/sign-up" className="rounded-md bg-[#58141E] px-4 py-2 text-sm font-semibold text-[#fffaf1] hover:bg-[#4A0E17]" data-testid="link-sign-up">إنشاء حساب</Link>
        </nav>
      </header>
      <section className="relative mx-auto grid max-w-7xl items-center gap-12 px-5 pb-16 pt-12 md:px-10 md:pb-24 md:pt-20 lg:grid-cols-[1.1fr_.9fr]">
        <div className="rise-in max-w-2xl">
          <div className="mb-7 flex items-center gap-3 text-xs font-semibold tracking-[.12em] text-[#8a6b32]">
            <span className="h-px w-9 bg-[#C5A059]" /> منظومة العمل الإجرائي
          </div>
          <h1 className="max-w-[700px] text-4xl font-bold leading-[1.4] tracking-tight md:text-6xl">
            من لحظة الورود،<br /><span className="font-serif text-[#9a7040]">حتى تمام الإحالة.</span>
          </h1>
          <p className="mt-7 max-w-xl text-base leading-8 text-[#665650] md:text-lg">
            سجل موحد لمعاملات الوارد الأولي؛ يربط التسجيل بالمراجعة والتوجيه والتفريغ، ويحفظ أثراً واضحاً لكل خطوة وصاحبها.
          </p>
          <div className="mt-9 flex flex-wrap gap-3">
            <Link href="/sign-in" className="inline-flex items-center gap-2 rounded-md bg-[#58141E] px-6 py-3 text-sm font-bold text-[#fffaf1] shadow-sm hover:bg-[#4A0E17]" data-testid="link-enter-system">الدخول إلى النظام <ArrowLeft size={16} /></Link>
            <a href="#workflow" className="inline-flex items-center rounded-md border border-[#cfc1ac] px-6 py-3 text-sm font-semibold hover:bg-white/70" data-testid="link-workflow">آلية سير المعاملة</a>
          </div>
          <div className="mt-14 grid max-w-lg grid-cols-3 divide-x divide-x-reverse divide-[#d6c9b7] border-y border-[#d6c9b7] py-4">
            {[['01', 'تسجيل موثق'], ['02', 'مراجعة وتوجيه'], ['03', 'إحالة قابلة للتتبع']].map(([n, text]) =>
              <div className="px-3 first:pr-0" key={n}><span className="font-mono text-xs text-[#9c7840]">{n}</span><p className="mt-2 text-xs font-semibold">{text}</p></div>
            )}
          </div>
        </div>
        <div className="rise-in-delay relative mx-auto w-full max-w-[510px]">
          <div className="relative border border-[#d8c9b2] bg-[#fffdf8] p-5 shadow-[0_24px_70px_rgba(74,14,23,.12)] md:p-8">
            <div className="absolute right-0 top-0 h-1 w-24 bg-[#C5A059]" />
            <div className="flex items-center justify-between border-b border-[#e8dfd2] pb-5">
              <div><div className="text-xs text-[#84776e]">مسار المعاملة</div><div className="mt-1 font-semibold">سجل موحد، أثر متصل</div></div>
              <div className="grid h-10 w-10 place-items-center border border-[#eadfcf] text-[#8c6937]"><History size={19} /></div>
            </div>
            <div className="relative mt-6 space-y-5 before:absolute before:bottom-5 before:right-[17px] before:top-5 before:w-px before:bg-[#decfae]">
              {[
                [FilePlus2, 'تسجيل الوارد', 'رقم سنوي ومرفق موثق', 'تم'],
                [BookOpen, 'مراجعة وتوجيه', 'اعتماد توجيه المدعي العام', 'مراجعة'],
                [FileCheck2, 'تفريغ وإحالة', 'وجهة واضحة وسجل زمني', 'لاحقاً'],
              ].map(([Icon, title, desc, label]: any, idx) => (
                <div className="relative flex items-center gap-4" key={title}>
                  <div className={`z-10 grid h-9 w-9 place-items-center border ${idx === 0 ? 'border-[#C5A059] bg-[#58141E] text-[#f8e7ba]' : 'border-[#e5daca] bg-[#fffdf8] text-[#876f53]'}`}><Icon size={16} /></div>
                  <div className="min-w-0 flex-1"><div className="flex items-center justify-between gap-2"><p className="text-sm font-bold">{title}</p><span className={`text-[10px] ${idx === 0 ? 'text-[#6c7b4d]' : 'text-[#8a8177]'}`}>{label}</span></div><p className="mt-1 text-xs text-[#81766c]">{desc}</p></div>
                </div>
              ))}
            </div>
            <div className="mt-7 flex items-center justify-between border-t border-[#e8dfd2] pt-4 text-[11px] text-[#80756b]">
              <span className="flex items-center gap-2"><ShieldCheck size={14} className="text-[#7d8060]" /> صلاحيات حسب الدور</span>
              <span className="font-mono">AUDIT / ACTIVE</span>
            </div>
          </div>
          <div className="absolute -bottom-5 -left-4 -z-0 h-24 w-24 border-b border-l border-[#C5A059]/70" />
        </div>
      </section>
      <section id="workflow" className="relative border-t border-[#ded3c3] bg-[#faf7f0]">
        <div className="mx-auto max-w-7xl px-5 py-14 md:px-10 md:py-20">
          <div className="mb-9 flex flex-col justify-between gap-3 md:flex-row md:items-end">
            <div><p className="text-xs font-bold tracking-[.12em] text-[#9a7843]">مسار واضح لكل معاملة</p><h2 className="mt-3 text-2xl font-bold md:text-3xl">كل مرحلة لها صاحب وأثر</h2></div>
            <p className="max-w-md text-sm leading-7 text-[#75695e]">واجهة عمل مؤسسية مصممة لتقليل الالتباس، مع إظهار الإجراءات المتاحة فقط وفق صلاحية المستخدم.</p>
          </div>
          <div className="grid gap-4 md:grid-cols-3">
            {[
              ['01', 'التسجيل السنوي', 'تسجيل بيانات المصدر والموضوع وإرفاق المستند الأصلي ضمن رقم وارد سنوي.'],
              ['02', 'المراجعة والتوجيه', 'استعراض المعاملة وصياغة المسودة ثم اعتماد التوجيه أو تسجيل سبب الرفض.'],
              ['03', 'التفريغ والإحالة', 'نسخ التوجيه المعتمد وتحديد الوجهة، ثم توثيق إتمام الإحالة في السجل.'],
            ].map(([n, title, text]) => <article key={n} className="border border-[#e2d8c9] bg-[#fffdf8] p-6">
              <div className="font-mono text-xs text-[#b18b4e]">{n} / WORKFLOW</div><h3 className="mt-5 text-lg font-bold">{title}</h3><p className="mt-3 text-sm leading-7 text-[#766a60]">{text}</p>
            </article>)}
          </div>
        </div>
      </section>
      <footer className="border-t border-[#ded3c3] px-5 py-5 text-center text-xs text-[#877b6e]">نظام الوارد الأولي <span className="mx-2 text-[#C5A059]">—</span> إدارة رقمية لسجل المعاملات</footer>
    </main>
  );
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();
  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
      appearance={{
        theme: shadcn,
        cssLayerName: 'clerk',
        variables: {
          colorPrimary: '#58141E', colorForeground: '#4A0E17', colorMutedForeground: '#786a60',
          colorDanger: '#a52d36', colorBackground: '#fffdf8', colorInput: '#fffdf8',
          colorInputForeground: '#4A0E17', colorNeutral: '#4A0E17', fontFamily: 'IBM Plex Sans Arabic',
          borderRadius: '6px',
        },
        elements: {
          rootBox: 'w-full flex justify-center',
          cardBox: 'bg-[#fffdf8] rounded-xl w-[440px] max-w-full overflow-hidden border border-[#e2d8c9] shadow-xl',
          card: '!shadow-none !border-0 !bg-transparent',
          footer: '!shadow-none !border-0 !bg-transparent',
          headerTitle: 'text-[#4A0E17] font-bold',
          headerSubtitle: 'text-[#786a60]',
          socialButtonsBlockButtonText: 'text-[#4A0E17]',
          formFieldLabel: 'text-[#4A0E17]',
          footerActionLink: 'text-[#58141E] font-semibold',
          footerActionText: 'text-[#786a60]',
          dividerText: 'text-[#786a60]',
          formButtonPrimary: 'bg-[#58141E] hover:bg-[#4A0E17]',
          formFieldInput: 'border-[#d9cbbb] text-[#4A0E17]',
          main: 'text-[#4A0E17]',
        },
      }}
      localization={arSA}
    >
      <ClerkQueryCacheInvalidator />
      <Router />
    </ClerkProvider>
  );
}

function ClerkQueryCacheInvalidator() {
  const { addListener } = useClerk();
  const queryClient = useQueryClient();
  const previousUserId = useRef<string | null | undefined>(undefined);
  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const nextId = user?.id ?? null;
      if (previousUserId.current !== undefined && previousUserId.current !== nextId) queryClient.clear();
      previousUserId.current = nextId;
    });
    return unsubscribe;
  }, [addListener, queryClient]);
  return null;
}

function SignInPage() {
  return <div className="flex min-h-[100dvh] flex-col items-center justify-center bg-[#f5f1e9] px-4 py-8" dir="rtl"><div className="mb-6"><Brand /></div><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} /></div>;
}
function SignUpPage() {
  return <div className="flex min-h-[100dvh] flex-col items-center justify-center bg-[#f5f1e9] px-4 py-8" dir="rtl"><div className="mb-6"><Brand /></div><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} /></div>;
}

const navItems = [
  { href: '/dashboard', label: 'لوحة المتابعة', icon: Gauge },
  { href: '/transactions', label: 'المعاملات', icon: Inbox },
];

function AppShell({ user, children }: { user: UserProfile; children: ReactNode }) {
  const [location] = useLocation();
  const { signOut } = useClerk();
  const [mobileMenu, setMobileMenu] = useState(false);
  const isAdmin = user.role === 'super_admin';
  return (
    <div className="min-h-[100dvh] bg-[#f5f2eb] text-[#3f2927]" dir="rtl">
      <aside className="fixed inset-y-0 right-0 z-30 hidden w-[258px] flex-col bg-[#58141E] text-[#fffaf1] md:flex">
        <div className="border-b border-white/10 px-6 py-6"><Brand /></div>
        <div className="px-5 pt-7"><div className="mb-3 px-3 text-[10px] font-semibold tracking-[.13em] text-[#e5c88c]/65">مساحة العمل</div>
          <nav className="space-y-1">
            {navItems.map(({ href, label, icon: Icon }) => <Link key={href} href={href} className={`flex items-center gap-3 rounded-md px-3 py-3 text-sm transition-colors ${location === href || (href === '/transactions' && location.startsWith('/transactions')) ? 'bg-[#fffaf1]/10 text-[#f0d99e]' : 'text-[#f4e9dc]/75 hover:bg-white/5 hover:text-white'}`} data-testid={`nav-${href.slice(1)}`}><Icon size={17} strokeWidth={1.8} />{label}</Link>)}
            {isAdmin && <Link href="/admin/users" className={`flex items-center gap-3 rounded-md px-3 py-3 text-sm ${location.startsWith('/admin') ? 'bg-[#fffaf1]/10 text-[#f0d99e]' : 'text-[#f4e9dc]/75 hover:bg-white/5'}`} data-testid="nav-admin-users"><Users size={17} strokeWidth={1.8} />إدارة المستخدمين</Link>}
          </nav>
        </div>
        <div className="mt-auto px-5 pb-5">
          <div className="mb-4 border-t border-white/10 pt-4">
            <div className="flex items-center gap-3 rounded-md bg-white/5 p-3">
              <div className="grid h-9 w-9 shrink-0 place-items-center border border-[#C5A059]/50 bg-[#4A0E17] text-sm font-bold text-[#e9cf98]">{user.displayName.trim().slice(0, 1) || 'م'}</div>
              <div className="min-w-0"><p className="truncate text-xs font-semibold" data-testid="text-current-user">{user.displayName}</p><p className="mt-1 truncate text-[10px] text-[#f4e9dc]/60">{roleText[user.role]}</p></div>
            </div>
          </div>
          <button type="button" onClick={() => signOut({ redirectUrl: basePath || '/' })} className="flex w-full items-center gap-3 rounded-md px-3 py-2 text-xs text-[#f4e9dc]/75 hover:bg-white/5" data-testid="button-sign-out"><LogOut size={15} />تسجيل الخروج</button>
          <div className="mt-4 text-center font-mono text-[9px] tracking-[.12em] text-[#f4e9dc]/35">INBOUND REGISTER · 01</div>
        </div>
      </aside>
      {mobileMenu && <div className="fixed inset-0 z-50 bg-[#16090c]/40 md:hidden" onClick={() => setMobileMenu(false)} data-testid="mobile-menu-backdrop">
        <aside className="flex h-full w-[min(300px,85vw)] flex-col bg-[#58141E] text-[#fffaf1]" onClick={(e) => e.stopPropagation()}>
          <div className="flex items-center justify-between border-b border-white/10 p-5"><Brand /><button aria-label="إغلاق القائمة" onClick={() => setMobileMenu(false)} data-testid="button-close-menu"><X size={18} /></button></div>
          <nav className="space-y-1 p-5">{navItems.map(({ href, label, icon: Icon }) => <Link key={href} href={href} onClick={() => setMobileMenu(false)} className="flex items-center gap-3 rounded-md px-3 py-3 text-sm hover:bg-white/10" data-testid={`mobile-nav-${href.slice(1)}`}><Icon size={17} />{label}</Link>)}{isAdmin && <Link href="/admin/users" onClick={() => setMobileMenu(false)} className="flex items-center gap-3 rounded-md px-3 py-3 text-sm hover:bg-white/10" data-testid="mobile-nav-admin"><Users size={17} />إدارة المستخدمين</Link>}</nav>
          <button className="mt-auto flex items-center gap-3 p-6 text-sm" onClick={() => signOut({ redirectUrl: basePath || '/' })} data-testid="mobile-sign-out"><LogOut size={16} />تسجيل الخروج</button>
        </aside>
      </div>}
      <div className="min-h-[100dvh] md:pr-[258px]">
        <header className="sticky top-0 z-20 flex h-[66px] items-center justify-between border-b border-[#e5ddd1] bg-[#fbf9f4]/95 px-4 backdrop-blur md:px-8">
          <div className="flex items-center gap-3">
            <button className="grid h-9 w-9 place-items-center border border-[#e5ddd1] md:hidden" onClick={() => setMobileMenu(true)} aria-label="فتح القائمة" data-testid="button-open-menu"><Menu size={18} /></button>
            <div className="hidden items-center gap-2 text-xs text-[#85776b] sm:flex"><Landmark size={15} className="text-[#9f7840]" /><span>مكتب النيابة العامة</span><ChevronLeft size={13} /><span className="font-semibold text-[#4A0E17]">{location.startsWith('/admin') ? 'إدارة المستخدمين' : location.startsWith('/transactions/new') ? 'تسجيل معاملة' : location.startsWith('/transactions/') && location !== '/transactions' ? 'تفاصيل المعاملة' : location === '/transactions' ? 'المعاملات' : 'لوحة المتابعة'}</span></div>
          </div>
          <div className="flex items-center gap-3">
            <span className="hidden border-l border-[#e5ddd1] pl-3 text-[11px] text-[#83776d] sm:inline">{user.department || 'الإدارة العامة'}</span>
            <div className="relative grid h-9 w-9 place-items-center rounded-full text-[#705d50]" aria-label="الإشعارات" data-testid="indicator-notifications"><Bell size={17} /><i className="absolute right-[8px] top-[7px] h-1.5 w-1.5 rounded-full bg-[#C5A059]" /></div>
            <div className="grid h-8 w-8 place-items-center bg-[#efe3ca] text-xs font-bold text-[#58141E]">{user.displayName.trim().slice(0, 1) || 'م'}</div>
          </div>
        </header>
        <main className="mx-auto w-full max-w-[1440px] px-4 py-6 md:px-8 md:py-9">{children}</main>
        <footer className="px-4 pb-5 text-center text-[10px] text-[#9b8c7d] md:px-8">نظام الوارد الأولي <span className="mx-1 text-[#C5A059]">/</span> سجل الإجراءات محفوظ وقابل للتتبع</footer>
      </div>
    </div>
  );
}

function LoadingPanel({ title = 'جارٍ تحميل البيانات' }: { title?: string }) {
  return <div className="space-y-4" aria-label={title} data-testid="loading-state"><div className="h-5 w-48 animate-pulse bg-[#e8e0d4]" /><div className="h-28 animate-pulse border border-[#e5ddd1] bg-[#faf8f3]" /><div className="h-48 animate-pulse border border-[#e5ddd1] bg-[#faf8f3]" /></div>;
}
function ErrorPanel({ error, retry }: { error: unknown; retry: () => void }) {
  return <div className="border border-red-200 bg-red-50 p-5 text-red-900" role="alert" data-testid="error-state"><div className="flex items-start gap-3"><ShieldAlert size={18} className="mt-0.5" /><div className="flex-1"><p className="font-bold">تعذر تحميل البيانات</p><p className="mt-1 text-sm">{errorMessage(error)}</p><button onClick={retry} className="mt-4 border border-red-300 px-3 py-2 text-xs font-semibold hover:bg-red-100" data-testid="button-retry">إعادة المحاولة</button></div></div></div>;
}
function PageHeading({ eyebrow, title, detail, action }: { eyebrow: string; title: string; detail: string; action?: ReactNode }) {
  return <div className="mb-7 flex flex-col gap-4 border-b border-[#e3dbcf] pb-6 sm:flex-row sm:items-end sm:justify-between"><div><div className="mb-2 flex items-center gap-2 text-[10px] font-bold tracking-[.12em] text-[#9c7941]"><span className="h-px w-5 bg-[#C5A059]" />{eyebrow}</div><h1 className="text-2xl font-bold tracking-tight text-[#4A0E17] md:text-3xl" data-testid="heading-page">{title}</h1><p className="mt-2 text-sm text-[#827569]">{detail}</p></div>{action}</div>;
}

function DashboardPage({ user }: { user: UserProfile }) {
  const summary = useGetDashboardSummary({ query: { queryKey: getGetDashboardSummaryQueryKey() } });
  const [, setLocation] = useLocation();
  const loading = summary.isLoading;
  const data = summary.data;
  const cards = [
    { title: 'إجمالي المعاملات', value: data?.totalTransactions, icon: ClipboardList, tone: 'burgundy' },
    { title: 'بانتظار التوجيه', value: data?.awaitingDirection, icon: Clock3, tone: 'gold' },
    { title: 'بانتظار التفريغ', value: data?.awaitingTranscription, icon: FileText, tone: 'blue' },
    { title: 'بانتظار الإحالة', value: data?.awaitingReferral, icon: ArrowUpRight, tone: 'green' },
    { title: 'إحالات هذا الشهر', value: data?.referredThisMonth, icon: BadgeCheck, tone: 'green' },
  ];
  return <div className="rise-in">
    <PageHeading eyebrow="نظرة عامة" title={`مرحباً، ${user.displayName}`} detail="ملخص سير العمل حسب صلاحيتك الحالية." action={<Link href="/transactions/new" className="inline-flex items-center justify-center gap-2 rounded-md bg-[#58141E] px-4 py-3 text-sm font-semibold text-white hover:bg-[#4A0E17]" data-testid="button-new-transaction"><FilePlus2 size={16} /> تسجيل معاملة</Link>} />
    {summary.isError ? <ErrorPanel error={summary.error} retry={() => void summary.refetch()} /> : loading ? <LoadingPanel /> : <>
      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5" data-testid="dashboard-summary">
        {cards.map(({ title, value, icon: Icon, tone }, index) => <article key={title} className={`relative overflow-hidden border border-[#e5ddd1] bg-[#fffdf8] p-5 ${index === 0 ? 'sm:col-span-2 xl:col-span-1' : ''}`} data-testid={`metric-${index}`}>
          <div className="flex items-start justify-between"><p className="text-xs text-[#7f7267]">{title}</p><span className={`grid h-8 w-8 place-items-center ${tone === 'burgundy' ? 'bg-[#f4e9e5] text-[#58141E]' : tone === 'gold' ? 'bg-[#f5efdF] text-[#94702f]' : tone === 'blue' ? 'bg-[#eaf0f2] text-[#506c79]' : 'bg-[#edf1e9] text-[#63754f]'}`}><Icon size={16} /></span></div>
          <div className="mt-5 font-mono text-3xl font-medium text-[#4A0E17]" data-testid={`value-${index}`}>{value ?? 0}</div>
          <div className="absolute bottom-0 right-0 h-[2px] w-12 bg-[#C5A059]/70" />
        </article>)}
      </section>
      <div className="mt-6 grid gap-5 xl:grid-cols-[1.45fr_.75fr]">
        <section className="border border-[#e5ddd1] bg-[#fffdf8]" aria-labelledby="activity-title">
          <div className="flex items-center justify-between border-b border-[#eee7dc] px-5 py-4"><div className="flex items-center gap-2"><Activity size={16} className="text-[#9b7841]" /><h2 id="activity-title" className="text-sm font-bold">آخر النشاطات</h2></div><span className="text-[10px] text-[#968a7e]">سجل الإجراء الأخير</span></div>
          {data?.recentActivity?.length ? <ol className="divide-y divide-[#f0ebe3]">
            {data.recentActivity.map((event) => <li className="flex gap-4 px-5 py-4" key={event.id} data-testid={`activity-${event.id}`}><div className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center border border-[#eadfcf] text-[#8b6b3c]"><History size={15} /></div><div className="min-w-0 flex-1"><p className="text-sm font-semibold leading-6">{event.description}</p><div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-[10px] text-[#8b7f73]"><span>{event.actorName}</span><span>{formatDate(event.createdAt)}</span></div></div></li>)}
          </ol> : <div className="px-6 py-12 text-center" data-testid="empty-activity"><div className="mx-auto grid h-11 w-11 place-items-center border border-[#eadfcf] text-[#a28a65]"><Activity size={18} /></div><p className="mt-4 text-sm font-semibold">لا توجد نشاطات بعد</p><p className="mt-1 text-xs text-[#92877c]">ستظهر الإجراءات هنا عند تسجيلها.</p></div>}
        </section>
        <section className="border border-[#e5ddd1] bg-[#fffdf8]">
          <div className="border-b border-[#eee7dc] px-5 py-4"><div className="flex items-center gap-2"><SlidersHorizontal size={16} className="text-[#9b7841]" /><h2 className="text-sm font-bold">اختصارات العمل</h2></div></div>
          <div className="space-y-2 p-4">
            <button onClick={() => setLocation('/transactions')} className="flex w-full items-center gap-3 border border-[#eee7dc] p-4 text-right hover:border-[#c8ad7a] hover:bg-[#fcfaf5]" data-testid="shortcut-transactions"><span className="grid h-9 w-9 place-items-center bg-[#f3ebe5] text-[#58141E]"><FolderOpen size={17} /></span><span className="flex-1"><b className="block text-xs">استعراض المعاملات</b><small className="mt-1 block text-[10px] text-[#8b7f73]">بحث وفرز حسب الحالة</small></span><ChevronLeft size={15} className="text-[#a29382]" /></button>
            <button onClick={() => setLocation('/transactions/new')} className="flex w-full items-center gap-3 border border-[#eee7dc] p-4 text-right hover:border-[#c8ad7a] hover:bg-[#fcfaf5]" data-testid="shortcut-register"><span className="grid h-9 w-9 place-items-center bg-[#f5f0e3] text-[#94702f]"><FilePlus2 size={17} /></span><span className="flex-1"><b className="block text-xs">تسجيل وارد جديد</b><small className="mt-1 block text-[10px] text-[#8b7f73]">رقم سنوي يولد عند الحفظ</small></span><ChevronLeft size={15} className="text-[#a29382]" /></button>
            {user.role === 'super_admin' && <button onClick={() => setLocation('/admin/users')} className="flex w-full items-center gap-3 border border-[#eee7dc] p-4 text-right hover:border-[#c8ad7a] hover:bg-[#fcfaf5]" data-testid="shortcut-users"><span className="grid h-9 w-9 place-items-center bg-[#edf0e8] text-[#67764f]"><UserCog size={17} /></span><span className="flex-1"><b className="block text-xs">إدارة الصلاحيات</b><small className="mt-1 block text-[10px] text-[#8b7f73]">تفعيل أدوار المستخدمين</small></span><ChevronLeft size={15} className="text-[#a29382]" /></button>}
          </div>
          <div className="mx-4 mb-4 flex gap-3 border-t border-[#eee7dc] pt-4 text-[10px] leading-5 text-[#8a7d70]"><LockKeyhole size={14} className="mt-0.5 shrink-0 text-[#a17b41]" /><p>تعرض اللوحة بيانات مسموحاً بها وفق دورك الوظيفي.</p></div>
        </section>
      </div>
    </>}
  </div>;
}

function StatusBadge({ status }: { status: TransactionStatus }) {
  return <span className={`inline-flex items-center whitespace-nowrap rounded-sm px-2 py-1 text-[10px] font-semibold ${statusStyle[status]}`} data-testid={`status-${status}`}>{statusText[status]}</span>;
}

function TransactionsPage() {
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('');
  const [year, setYear] = useState('');
  const [offset, setOffset] = useState(0);
  const params = useMemo(() => ({ query: query || undefined, status: status ? status as TransactionStatus : undefined, year: year ? Number(year) : undefined, limit: 30, offset }), [query, status, year, offset]);
  const list = useListTransactions(params);
  const records = list.data?.items ?? [];
  return <div className="rise-in">
    <PageHeading eyebrow="السجل الرقمي" title="المعاملات الواردة" detail="ابحث في المعاملات التي تسمح صلاحيتك بالاطلاع عليها." action={<Link href="/transactions/new" className="inline-flex items-center justify-center gap-2 rounded-md bg-[#58141E] px-4 py-3 text-sm font-semibold text-white hover:bg-[#4A0E17]" data-testid="button-register-transaction"><FilePlus2 size={16} /> تسجيل معاملة</Link>} />
    <section className="mb-5 border border-[#e5ddd1] bg-[#fffdf8] p-4">
      <div className="grid gap-3 md:grid-cols-[1fr_220px_140px]">
        <label className="relative block"><span className="sr-only">بحث في المعاملات</span><Search className="absolute right-3 top-1/2 -translate-y-1/2 text-[#97897b]" size={16} /><input value={query} onChange={(e) => { setQuery(e.target.value); setOffset(0); }} placeholder="ابحث بالموضوع أو المرسل أو رقم الوارد..." className="h-11 w-full border border-[#e1d8cc] bg-[#fffdf8] pr-10 pl-3 text-sm outline-none focus:border-[#a88b5a]" data-testid="input-search-transactions" /></label>
        <label className="flex items-center gap-2"><span className="shrink-0 text-xs text-[#85796e]">الحالة</span><select value={status} onChange={(e) => { setStatus(e.target.value); setOffset(0); }} className="h-11 min-w-0 flex-1 border border-[#e1d8cc] bg-[#fffdf8] px-3 text-xs outline-none focus:border-[#a88b5a]" data-testid="select-transaction-status"><option value="">كل الحالات</option>{Object.entries(statusText).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label>
        <label className="flex items-center gap-2"><span className="shrink-0 text-xs text-[#85796e]">السنة</span><input type="number" min="2000" max="2200" value={year} onChange={(e) => { setYear(e.target.value); setOffset(0); }} placeholder="الكل" className="h-11 w-full border border-[#e1d8cc] bg-[#fffdf8] px-3 text-sm outline-none focus:border-[#a88b5a]" data-testid="input-filter-year" /></label>
      </div>
      <div className="mt-3 flex items-center justify-between text-[10px] text-[#968a7e]"><span>{list.data ? `${list.data.total} نتيجة` : 'تصفية حسب بيانات السجل'}</span><button onClick={() => { setQuery(''); setStatus(''); setYear(''); setOffset(0); }} className="hover:text-[#58141E]" data-testid="button-clear-filters">مسح عوامل التصفية</button></div>
    </section>
    {list.isLoading ? <LoadingPanel title="جارٍ تحميل المعاملات" /> : list.isError ? <ErrorPanel error={list.error} retry={() => void list.refetch()} /> : records.length === 0 ? <div className="border border-dashed border-[#d8cdbd] bg-[#faf8f3] px-6 py-14 text-center" data-testid="empty-transactions"><div className="mx-auto grid h-12 w-12 place-items-center border border-[#e5ddd1] text-[#a18a63]"><Inbox size={20} /></div><h2 className="mt-4 text-sm font-bold">لا توجد معاملات مطابقة</h2><p className="mx-auto mt-2 max-w-sm text-xs leading-6 text-[#8c8074]">{query || status || year ? 'جرّب تعديل البحث أو عوامل التصفية.' : 'لم تُسجل معاملات مرئية حالياً. ابدأ بتسجيل معاملة جديدة عند ورودها.'}</p>{!query && !status && !year && <Link href="/transactions/new" className="mt-5 inline-flex items-center gap-2 border border-[#c9b99e] px-4 py-2 text-xs font-semibold text-[#58141E] hover:bg-white" data-testid="link-first-transaction"><FilePlus2 size={14} /> تسجيل معاملة</Link>}</div> :
      <div className="overflow-hidden border border-[#e5ddd1] bg-[#fffdf8]">
        <div className="hidden grid-cols-[130px_minmax(200px,1.4fr)_minmax(140px,.8fr)_120px_110px] gap-4 border-b border-[#e8e0d5] bg-[#f7f3eb] px-5 py-3 text-[10px] font-semibold text-[#786c60] lg:grid"><span>رقم الوارد</span><span>الموضوع والمرسل</span><span>المصدر</span><span>تاريخ الورود</span><span>الحالة</span></div>
        <div className="divide-y divide-[#eee8df]">
          {records.map((tx) => <Link href={`/transactions/${tx.id}`} key={tx.id} className="grid gap-3 px-4 py-4 transition-colors hover:bg-[#faf7f0] sm:px-5 lg:grid-cols-[130px_minmax(200px,1.4fr)_minmax(140px,.8fr)_120px_110px] lg:items-center lg:gap-4" data-testid={`row-transaction-${tx.id}`}>
            <div className="flex items-center justify-between gap-3 lg:block"><span className="font-mono text-sm font-medium text-[#58141E]" data-testid={`number-transaction-${tx.id}`}>{tx.inboundNumber}/{tx.year}</span><span className="lg:hidden"><StatusBadge status={tx.status} /></span></div>
            <div className="min-w-0"><p className="truncate text-sm font-semibold text-[#4A0E17]">{tx.subject}</p><p className="mt-1 truncate text-[10px] text-[#8b7e72]">{tx.senderName}</p></div>
            <div className="hidden truncate text-xs text-[#766a5e] lg:block">{tx.source}</div>
            <div className="hidden text-xs text-[#766a5e] lg:block">{formatDay(tx.receivedDate)}</div>
            <div className="hidden lg:block"><StatusBadge status={tx.status} /></div>
          </Link>)}
        </div>
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[#eee8df] px-5 py-3 text-[10px] text-[#968a7e]"><span>عرض {records.length} من {list.data?.total ?? 0}</span><div className="flex items-center gap-3"><span className="flex items-center gap-1"><span className="font-mono">{Math.floor(offset / 30 + 1).toString().padStart(2, '0')}</span><span>/</span><span className="font-mono">{Math.max(1, Math.ceil((list.data?.total ?? 0) / 30)).toString().padStart(2, '0')}</span></span><button disabled={offset === 0} onClick={() => setOffset((value) => Math.max(0, value - 30))} className="border border-[#e1d8cc] px-3 py-2 disabled:opacity-40" data-testid="button-previous-page">السابق</button><button disabled={offset + 30 >= (list.data?.total ?? 0)} onClick={() => setOffset((value) => value + 30)} className="border border-[#e1d8cc] px-3 py-2 disabled:opacity-40" data-testid="button-next-page">التالي</button></div></div>
      </div>}
  </div>;
}

type RegistrationValues = {
  subject: string;
  senderName: string;
  source: string;
  receivedDate: string;
  confidentiality: Confidentiality;
  urgency: Urgency;
  notes: string;
};

function NewTransactionPage() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [file, setFile] = useState<File | null>(null);
  const [uploadError, setUploadError] = useState('');
  const [successTx, setSuccessTx] = useState<Transaction | null>(null);
  const requestUpload = useRequestUploadUrl();
  const create = useCreateTransaction();
  const form = useForm<RegistrationValues>({
    defaultValues: { subject: '', senderName: '', source: '', receivedDate: new Date().toISOString().slice(0, 10), confidentiality: 'normal', urgency: 'normal', notes: '' },
  });
  async function submit(values: RegistrationValues) {
    setUploadError('');
    if (!file) { setUploadError('أرفق مستند المعاملة قبل الحفظ.'); return; }
    try {
      const contentType = file.type as 'application/pdf' | 'image/jpeg' | 'image/png';
      const upload = await requestUpload.mutateAsync({ data: { name: file.name, size: file.size, contentType } });
      const put = await fetch(upload.uploadURL, { method: 'PUT', headers: { 'Content-Type': contentType }, body: file });
      if (!put.ok) throw new Error('فشل رفع الملف إلى مساحة التخزين.');
      const digest = await crypto.subtle.digest('SHA-256', await file.arrayBuffer());
      const sha256 = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, '0')).join('');
      const attachment: Attachment = { objectPath: upload.objectPath, fileName: file.name, contentType, size: file.size, sha256 };
      const transaction = await create.mutateAsync({ data: {
        subject: values.subject.trim(), senderName: values.senderName.trim(), source: values.source.trim(),
        receivedDate: values.receivedDate, confidentiality: values.confidentiality, urgency: values.urgency,
        notes: values.notes.trim() || undefined, attachment,
      } });
      await queryClient.invalidateQueries({ queryKey: getListTransactionsQueryKey(undefined) });
      await queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
      setSuccessTx(transaction);
    } catch (error) { setUploadError(errorMessage(error)); }
  }
  const busy = requestUpload.isPending || create.isPending;
  if (successTx) return <div className="mx-auto max-w-2xl border border-[#e4dacb] bg-[#fffdf8] p-7 text-center md:p-12" data-testid="registration-success"><div className="mx-auto grid h-14 w-14 place-items-center border border-[#d8c59e] bg-[#f5f0e3] text-[#80612e]"><Check size={24} /></div><p className="mt-6 text-[10px] font-bold tracking-[.14em] text-[#9c7941]">تم التسجيل بنجاح</p><h1 className="mt-2 text-2xl font-bold text-[#4A0E17]">أُضيفت المعاملة إلى السجل</h1><p className="mt-3 text-sm text-[#827569]">رقم الوارد السنوي المخصص لهذه المعاملة</p><div className="mx-auto mt-5 inline-flex border border-[#d7c9b1] bg-[#f8f5ee] px-6 py-3 font-mono text-xl font-medium text-[#58141E]" data-testid="text-new-inbound-number">{successTx.inboundNumber}/{successTx.year}</div><div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row"><button onClick={() => setLocation(`/transactions/${successTx.id}`)} className="bg-[#58141E] px-5 py-3 text-sm font-semibold text-white hover:bg-[#4A0E17]" data-testid="button-open-created">عرض المعاملة</button><button onClick={() => setLocation('/transactions')} className="border border-[#d8cdbd] px-5 py-3 text-sm font-semibold text-[#58141E] hover:bg-[#f8f5ee]" data-testid="button-back-transactions">العودة إلى السجل</button></div></div>;
  return <div className="rise-in">
    <PageHeading eyebrow="تسجيل وارد" title="تسجيل معاملة جديدة" detail="أدخل بيانات المستند الوارد وأرفق نسخة رقمية واحدة. الرقم السنوي يخصص عند الحفظ." />
    <div className="mb-5 flex items-start gap-3 border border-[#e7d7b5] bg-[#faf5e9] p-4 text-xs leading-6 text-[#715b36]"><LockKeyhole size={16} className="mt-1 shrink-0" /><p>تُحفظ المعاملة في سجل الصلاحيات، ويُنشأ رقم الوارد تلقائياً بواسطة النظام عند اكتمال التسجيل.</p></div>
    <Form {...form}>
      <form onSubmit={form.handleSubmit(submit)} className="space-y-5" data-testid="form-new-transaction">
        <section className="border border-[#e5ddd1] bg-[#fffdf8]">
          <div className="flex items-center gap-3 border-b border-[#eee7dc] px-5 py-4"><span className="font-mono text-[10px] text-[#a17c42]">01</span><div><h2 className="text-sm font-bold">بيانات المعاملة</h2><p className="mt-1 text-[10px] text-[#8b7e72]">المعلومات الأساسية للمصدر والموضوع</p></div></div>
          <div className="grid gap-5 p-5 md:grid-cols-2">
            <FormField control={form.control} name="subject" rules={{ required: 'أدخل موضوع المعاملة.', minLength: { value: 3, message: 'يجب ألا يقل الموضوع عن 3 أحرف.' }, maxLength: { value: 500, message: 'الحد الأقصى 500 حرف.' } }} render={({ field }) => <FormItem><FormLabel>موضوع المعاملة <span className="text-[#a54b43]">*</span></FormLabel><FormControl><Input {...field} placeholder="عنوان مختصر وواضح للمعاملة" data-testid="input-subject" /></FormControl><FormMessage /></FormItem>} />
            <FormField control={form.control} name="senderName" rules={{ required: 'أدخل اسم المرسل.', minLength: { value: 2, message: 'الاسم قصير جداً.' } }} render={({ field }) => <FormItem><FormLabel>اسم المرسل <span className="text-[#a54b43]">*</span></FormLabel><FormControl><Input {...field} placeholder="الجهة أو الشخص المرسل" data-testid="input-sender" /></FormControl><FormMessage /></FormItem>} />
            <FormField control={form.control} name="source" rules={{ required: 'أدخل جهة المصدر.', minLength: { value: 2, message: 'أدخل جهة المصدر.' } }} render={({ field }) => <FormItem><FormLabel>جهة المصدر <span className="text-[#a54b43]">*</span></FormLabel><FormControl><Input {...field} placeholder="الجهة التي وردت منها المعاملة" data-testid="input-source" /></FormControl><FormMessage /></FormItem>} />
            <FormField control={form.control} name="receivedDate" rules={{ required: 'حدد تاريخ الورود.' }} render={({ field }) => <FormItem><FormLabel>تاريخ الورود <span className="text-[#a54b43]">*</span></FormLabel><FormControl><Input {...field} type="date" data-testid="input-received-date" /></FormControl><FormMessage /></FormItem>} />
            <FormField control={form.control} name="confidentiality" render={({ field }) => <FormItem><FormLabel>درجة السرية</FormLabel><FormControl><select {...field} className="h-10 w-full border border-input bg-background px-3 text-sm outline-none focus:border-[#a88b5a]" data-testid="select-confidentiality">{Object.entries(confidentialityText).map(([key, value]) => <option key={key} value={key}>{value}</option>)}</select></FormControl><FormMessage /></FormItem>} />
            <FormField control={form.control} name="urgency" render={({ field }) => <FormItem><FormLabel>درجة الاستعجال</FormLabel><FormControl><select {...field} className="h-10 w-full border border-input bg-background px-3 text-sm outline-none focus:border-[#a88b5a]" data-testid="select-urgency">{Object.entries(urgencyText).map(([key, value]) => <option key={key} value={key}>{value}</option>)}</select></FormControl><FormMessage /></FormItem>} />
            <FormField control={form.control} name="notes" render={({ field }) => <FormItem className="md:col-span-2"><FormLabel>ملاحظات التسجيل <span className="text-xs font-normal text-[#8b7e72]">(اختياري)</span></FormLabel><FormControl><Textarea {...field} rows={3} maxLength={4000} placeholder="ملاحظات إدارية مرتبطة بالتسجيل..." data-testid="input-notes" /></FormControl><FormMessage /></FormItem>} />
          </div>
        </section>
        <section className="border border-[#e5ddd1] bg-[#fffdf8]">
          <div className="flex items-center gap-3 border-b border-[#eee7dc] px-5 py-4"><span className="font-mono text-[10px] text-[#a17c42]">02</span><div><h2 className="text-sm font-bold">المستند الأصلي</h2><p className="mt-1 text-[10px] text-[#8b7e72]">ملف واحد بصيغة PDF أو JPG أو PNG، حتى 15 ميغابايت</p></div></div>
          <div className="p-5">
            <label className={`flex min-h-[120px] cursor-pointer flex-col items-center justify-center border border-dashed px-4 py-6 text-center transition-colors ${file ? 'border-[#b49b6c] bg-[#faf7ef]' : 'border-[#d8cdbd] hover:border-[#b49b6c] hover:bg-[#faf8f3]'}`}>
              <Paperclip size={19} className="text-[#967743]" /><span className="mt-3 text-sm font-semibold">{file ? file.name : 'اختر ملفاً لإرفاقه'}</span><span className="mt-1 text-[10px] text-[#8b7e72]">{file ? `${(file.size / 1048576).toFixed(2)} MB` : 'اضغط للاستعراض من جهازك'}</span>
              <input type="file" className="sr-only" accept="application/pdf,image/jpeg,image/png,.pdf,.jpg,.jpeg,.png" onChange={(e) => { const selected = e.target.files?.[0] ?? null; setUploadError(''); if (selected && selected.size > 15728640) { setFile(null); setUploadError('يتجاوز الملف الحد الأقصى المسموح به (15 ميغابايت).'); return; } if (selected && !['application/pdf', 'image/jpeg', 'image/png'].includes(selected.type)) { setFile(null); setUploadError('الصيغ المدعومة هي PDF وJPG وPNG فقط.'); return; } setFile(selected); }} data-testid="input-attachment" />
            </label>
            {file && <button type="button" onClick={() => setFile(null)} className="mt-3 flex items-center gap-2 text-xs text-[#8c423c] hover:underline" data-testid="button-remove-attachment"><X size={13} /> إزالة المرفق</button>}
            {uploadError && <p className="mt-3 text-xs text-red-700" role="alert" data-testid="error-upload">{uploadError}</p>}
            {(requestUpload.isPending || create.isPending) && <div className="mt-3 flex items-center gap-2 text-xs text-[#80663b]" data-testid="upload-progress"><span className="h-2 w-2 animate-pulse rounded-full bg-[#C5A059]" />{requestUpload.isPending ? 'جارٍ تجهيز الرفع الآمن...' : 'جارٍ حفظ المعاملة...'}</div>}
          </div>
        </section>
        <div className="flex flex-col-reverse justify-between gap-3 sm:flex-row sm:items-center"><Link href="/transactions" className="px-4 py-3 text-center text-sm text-[#76695e] hover:text-[#58141E]" data-testid="link-cancel-registration">إلغاء والعودة للسجل</Link><Button type="submit" disabled={busy} className="min-w-44 gap-2 bg-[#58141E] hover:bg-[#4A0E17]" data-testid="button-save-transaction"><FileCheck2 size={16} />{busy ? 'جارٍ حفظ المعاملة...' : 'حفظ وتسجيل الوارد'}</Button></div>
      </form>
    </Form>
  </div>;
}

function TransactionDetailPage({ user, id }: { user: UserProfile; id: string }) {
  const transactionQuery = useGetTransaction(id, { query: { queryKey: getGetTransactionQueryKey(id) } });
  const timelineQuery = useGetTransactionTimeline(id, { query: { queryKey: getGetTransactionTimelineQueryKey(id) } });
  const queryClient = useQueryClient();
  const submit = useSubmitTransaction();
  const draft = useSaveDirectiveDraft();
  const approve = useApproveDirective();
  const reject = useRejectTransaction();
  const saveReferral = useSaveReferral();
  const dispatch = useDispatchTransaction();
  const [directiveText, setDirectiveText] = useState('');
  const [transcription, setTranscription] = useState('');
  const [destination, setDestination] = useState('');
  const [rejectReason, setRejectReason] = useState('');
  const [rejectOpen, setRejectOpen] = useState(false);
  const [actionError, setActionError] = useState('');
  const tx = transactionQuery.data;
  const refreshTransaction = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: getGetTransactionQueryKey(id) }),
      queryClient.invalidateQueries({ queryKey: getGetTransactionTimelineQueryKey(id) }),
      queryClient.invalidateQueries({ queryKey: getListTransactionsQueryKey(undefined) }),
      queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() }),
    ]);
  };
  if (transactionQuery.isLoading) return <LoadingPanel title="جارٍ تحميل المعاملة" />;
  if (transactionQuery.isError) return <ErrorPanel error={transactionQuery.error} retry={() => void transactionQuery.refetch()} />;
  if (!tx) return <NotFound />;
  const run = (mutation: { mutateAsync: (...args: any[]) => Promise<unknown> }, variables: any) => {
    setActionError('');
    return mutation.mutateAsync(variables).then(refreshTransaction).catch((error: unknown) => setActionError(errorMessage(error)));
  };
  const roleProsecutor = user.role === 'prosecutor' || user.role === 'super_admin';
  const roleEmployee = user.role === 'employee' || user.role === 'department_manager' || user.role === 'super_admin';
  const canSubmit = tx.status === 'registered' && (tx.createdBy === user.userId || user.role === 'super_admin');
  const canDirect = roleProsecutor && ['awaiting_direction', 'in_review', 'directive_draft'].includes(tx.status);
  const canTranscribe = roleEmployee && ['awaiting_transcription', 'awaiting_referral'].includes(tx.status);
  const isBusy = submit.isPending || draft.isPending || approve.isPending || reject.isPending || saveReferral.isPending || dispatch.isPending;
  const attachmentUrl = tx.attachment?.objectPath ? `/api/storage${tx.attachment.objectPath}` : '';
  return <div className="rise-in">
    <div className="mb-5"><Link href="/transactions" className="inline-flex items-center gap-2 text-xs text-[#817468] hover:text-[#58141E]" data-testid="link-back-list"><ArrowLeft size={14} /> العودة إلى المعاملات</Link></div>
    <div className="mb-6 flex flex-col gap-4 border-b border-[#e3dbcf] pb-6 md:flex-row md:items-start md:justify-between">
      <div><div className="mb-2 flex items-center gap-2 text-[10px] font-bold tracking-[.12em] text-[#9c7941]"><span className="h-px w-5 bg-[#C5A059]" />ملف المعاملة</div><div className="flex flex-wrap items-center gap-3"><h1 className="text-2xl font-bold text-[#4A0E17] md:text-3xl" data-testid="text-transaction-number">{tx.inboundNumber}/{tx.year}</h1><StatusBadge status={tx.status} /></div><p className="mt-2 max-w-3xl text-sm leading-6 text-[#827569]" data-testid="text-transaction-subject">{tx.subject}</p></div>
      <div className="flex flex-wrap gap-2">
        {canSubmit && <button disabled={isBusy} onClick={() => void run(submit, { id })} className="inline-flex items-center gap-2 bg-[#58141E] px-4 py-2.5 text-xs font-semibold text-white hover:bg-[#4A0E17] disabled:opacity-50" data-testid="button-submit-transaction"><ArrowUpRight size={15} />إرسال للمراجعة</button>}
        {canDirect && <button onClick={() => document.getElementById('directive-panel')?.scrollIntoView({ behavior: 'smooth' })} className="inline-flex items-center gap-2 bg-[#58141E] px-4 py-2.5 text-xs font-semibold text-white hover:bg-[#4A0E17]" data-testid="button-open-directive">إجراء التوجيه <ChevronDown size={14} /></button>}
        {tx.status === 'awaiting_referral' && roleEmployee && <button onClick={() => document.getElementById('referral-panel')?.scrollIntoView({ behavior: 'smooth' })} className="inline-flex items-center gap-2 bg-[#58141E] px-4 py-2.5 text-xs font-semibold text-white hover:bg-[#4A0E17]" data-testid="button-open-referral">إتمام الإحالة <ArrowUpRight size={14} /></button>}
      </div>
    </div>
    <div className="grid items-start gap-5 xl:grid-cols-[minmax(0,1.4fr)_minmax(280px,.75fr)]">
      <div className="space-y-5">
        <section className="border border-[#e5ddd1] bg-[#fffdf8]" data-testid="transaction-information">
          <div className="flex items-center gap-2 border-b border-[#eee7dc] px-5 py-4"><ClipboardList size={16} className="text-[#9a7842]" /><h2 className="text-sm font-bold">بيانات المعاملة</h2></div>
          <div className="grid gap-x-8 gap-y-5 p-5 sm:grid-cols-2">
            {[
              ['المرسل', tx.senderName], ['جهة المصدر', tx.source], ['تاريخ الورود', formatDay(tx.receivedDate)],
              ['تاريخ التسجيل', formatDate(tx.registeredAt)], ['درجة السرية', confidentialityText[tx.confidentiality]], ['الاستعجال', urgencyText[tx.urgency]],
              ['مسجل المعاملة', tx.createdByName],
            ].map(([label, value]) => <div key={label}><p className="text-[10px] text-[#8c8074]">{label}</p><p className="mt-1.5 text-sm font-semibold text-[#4A0E17]" data-testid={`detail-${label}`}>{value || '—'}</p></div>)}
            {tx.notes && <div className="sm:col-span-2"><p className="text-[10px] text-[#8c8074]">ملاحظات التسجيل</p><p className="mt-1.5 whitespace-pre-wrap text-sm leading-7">{tx.notes}</p></div>}
          </div>
        </section>
        {(tx.directiveText || tx.referralDestination) && <section className="border border-[#e5ddd1] bg-[#fffdf8]" data-testid="transaction-directive"><div className="flex items-center gap-2 border-b border-[#eee7dc] px-5 py-4"><FileCheck2 size={16} className="text-[#9a7842]" /><h2 className="text-sm font-bold">التوجيه والإحالة</h2></div><div className="space-y-4 p-5">{tx.directiveText && <div><p className="text-[10px] text-[#8c8074]">نص التوجيه المعتمد</p><p className="mt-2 whitespace-pre-wrap text-sm leading-7">{tx.directiveText}</p></div>}{tx.referralDestination && <div className="border-t border-[#eee7dc] pt-4"><p className="text-[10px] text-[#8c8074]">جهة الإحالة</p><p className="mt-1.5 text-sm font-semibold">{tx.referralDestination}</p></div>}</div></section>}
        {canDirect && <section id="directive-panel" className="border border-[#d9c9a8] bg-[#fffdf8]" data-testid="panel-directive-actions"><div className="flex items-center gap-2 border-b border-[#eee7dc] px-5 py-4"><BookOpen size={16} className="text-[#9a7842]" /><div><h2 className="text-sm font-bold">مراجعة وتوجيه</h2><p className="mt-1 text-[10px] text-[#8c8074]">صياغة التوجيه ثم اعتماده أو تسجيل سبب الرفض</p></div></div><div className="space-y-4 p-5"><label className="block"><span className="mb-2 block text-xs font-semibold">مسودة التوجيه</span><textarea value={directiveText || tx.directiveText || ''} onChange={(e) => setDirectiveText(e.target.value)} rows={5} maxLength={10000} className="w-full border border-[#e1d8cc] bg-[#fffdf8] p-3 text-sm leading-7 outline-none focus:border-[#a88b5a]" placeholder="اكتب نص التوجيه المقترح..." data-testid="input-directive-text" /></label><div className="flex flex-wrap gap-2"><button disabled={isBusy || !(directiveText || tx.directiveText)} onClick={() => void run(draft, { id, data: { text: directiveText || tx.directiveText || '', expectedVersion: tx.version } })} className="border border-[#c9b99e] px-4 py-2.5 text-xs font-semibold text-[#58141E] hover:bg-[#faf7f0] disabled:opacity-50" data-testid="button-save-directive">حفظ المسودة</button><button disabled={isBusy} onClick={() => void run(approve, { id, data: { expectedVersion: tx.version } })} className="inline-flex items-center gap-2 bg-[#58141E] px-4 py-2.5 text-xs font-semibold text-white hover:bg-[#4A0E17] disabled:opacity-50" data-testid="button-approve-directive"><Check size={14} />اعتماد التوجيه</button><button onClick={() => setRejectOpen(!rejectOpen)} className="border border-[#dcbab7] px-4 py-2.5 text-xs font-semibold text-[#9b3937] hover:bg-red-50" data-testid="button-toggle-reject">رفض المعاملة</button></div>{rejectOpen && <div className="border-t border-[#eee7dc] pt-4"><label className="mb-2 block text-xs font-semibold">سبب الرفض</label><textarea value={rejectReason} onChange={(e) => setRejectReason(e.target.value)} rows={3} className="w-full border border-[#e1d8cc] p-3 text-sm outline-none focus:border-[#a88b5a]" placeholder="اكتب سبباً واضحاً للرفض..." data-testid="input-rejection-reason" /><button disabled={isBusy || !rejectReason.trim()} onClick={() => void run(reject, { id, data: { reason: rejectReason.trim() } })} className="mt-3 bg-[#9b3937] px-4 py-2.5 text-xs font-semibold text-white disabled:opacity-50" data-testid="button-reject-transaction">تأكيد الرفض</button></div>}</div></section>}
        {canTranscribe && <section id="referral-panel" className="border border-[#d9c9a8] bg-[#fffdf8]" data-testid="panel-referral-actions"><div className="flex items-center gap-2 border-b border-[#eee7dc] px-5 py-4"><FileText size={16} className="text-[#9a7842]" /><div><h2 className="text-sm font-bold">تفريغ التوجيه والإحالة</h2><p className="mt-1 text-[10px] text-[#8c8074]">انسخ التوجيه المعتمد وحدد وجهة الإحالة</p></div></div><div className="space-y-4 p-5"><label className="block"><span className="mb-2 block text-xs font-semibold">نص التفريغ</span><textarea value={transcription || tx.directiveText || ''} onChange={(e) => setTranscription(e.target.value)} rows={5} maxLength={10000} className="w-full border border-[#e1d8cc] p-3 text-sm leading-7 outline-none focus:border-[#a88b5a]" placeholder="أدخل نص التوجيه بعد تفريغه..." data-testid="input-transcription" /></label><label className="block"><span className="mb-2 block text-xs font-semibold">وجهة الإحالة</span><input value={destination || tx.referralDestination || ''} onChange={(e) => setDestination(e.target.value)} maxLength={300} className="h-10 w-full border border-[#e1d8cc] px-3 text-sm outline-none focus:border-[#a88b5a]" placeholder="اسم الجهة أو القسم" data-testid="input-referral-destination" /></label><div className="flex flex-wrap gap-2"><button disabled={isBusy || !transcription.trim() || !destination.trim()} onClick={() => void run(saveReferral, { id, data: { transcription: transcription.trim(), destination: destination.trim(), expectedVersion: tx.version } })} className="border border-[#c9b99e] px-4 py-2.5 text-xs font-semibold text-[#58141E] disabled:opacity-50" data-testid="button-save-referral">حفظ التفريغ والوجهة</button>{tx.referralDestination && <button disabled={isBusy} onClick={() => void run(dispatch, { id })} className="inline-flex items-center gap-2 bg-[#58141E] px-4 py-2.5 text-xs font-semibold text-white disabled:opacity-50" data-testid="button-dispatch-transaction"><ArrowUpRight size={14} />تأكيد الإحالة</button>}</div></div></section>}
      </div>
      <aside className="space-y-5">
        <section className="border border-[#e5ddd1] bg-[#fffdf8]" data-testid="document-panel"><div className="flex items-center justify-between border-b border-[#eee7dc] px-5 py-4"><div className="flex items-center gap-2"><FileText size={16} className="text-[#9a7842]" /><h2 className="text-sm font-bold">المستند الأصلي</h2></div>{tx.attachment && <a href={attachmentUrl} target="_blank" rel="noreferrer" className="text-[10px] font-semibold text-[#77582d] hover:underline" data-testid="link-open-document">فتح الملف</a>}</div>{tx.attachment ? <div className="p-4"><div className="flex items-start gap-3 border border-[#eee7dc] bg-[#faf8f3] p-4"><div className="grid h-10 w-10 shrink-0 place-items-center bg-[#f0e8d8] text-[#85683a]"><FileText size={18} /></div><div className="min-w-0"><p className="break-all text-xs font-semibold" data-testid="text-attachment-name">{tx.attachment.fileName}</p><p className="mt-1 text-[10px] text-[#8b7e72]">{(tx.attachment.size / 1048576).toFixed(2)} MB · {tx.attachment.contentType}</p></div></div>{tx.attachment.contentType === 'application/pdf' && <iframe title="معاينة المستند المرفق" src={attachmentUrl} className="mt-4 h-[360px] w-full border border-[#eee7dc] bg-white" data-testid="document-preview" />}{tx.attachment.contentType.startsWith('image/') && <img src={attachmentUrl} alt={tx.attachment.fileName} className="mt-4 max-h-[360px] w-full border border-[#eee7dc] object-contain" data-testid="document-preview-image" />}</div> : <div className="p-6 text-center text-xs text-[#8b7e72]" data-testid="empty-attachment">لا يوجد مستند مرفق.</div>}</section>
        <section className="border border-[#e5ddd1] bg-[#fffdf8]" data-testid="timeline-panel"><div className="flex items-center gap-2 border-b border-[#eee7dc] px-5 py-4"><History size={16} className="text-[#9a7842]" /><h2 className="text-sm font-bold">السجل الزمني</h2></div>{timelineQuery.isLoading ? <div className="space-y-3 p-5"><div className="h-10 animate-pulse bg-[#f1ede5]" /><div className="h-10 animate-pulse bg-[#f1ede5]" /></div> : timelineQuery.isError ? <div className="p-4 text-xs text-red-700" role="alert" data-testid="timeline-error"><p>تعذر تحميل السجل الزمني.</p><button className="mt-2 underline" onClick={() => void timelineQuery.refetch()} data-testid="button-retry-timeline">إعادة المحاولة</button></div> : timelineQuery.data?.length ? <ol className="relative space-y-0 px-5 py-3 before:absolute before:bottom-7 before:right-[28px] before:top-7 before:w-px before:bg-[#e5d8bd]">{timelineQuery.data.map((event) => <li className="relative flex gap-3 py-3" key={event.id} data-testid={`timeline-event-${event.id}`}><span className="z-10 mt-1 grid h-7 w-7 shrink-0 place-items-center border border-[#e7dcc9] bg-[#fffdf8] text-[#98753e]"><History size={13} /></span><div className="min-w-0"><p className="text-xs font-semibold leading-5">{event.description}</p><p className="mt-1 text-[10px] text-[#8c8074]">{event.actorName}</p><time className="mt-1 block text-[9px] text-[#a19589]">{formatDate(event.createdAt)}</time></div></li>)}</ol> : <div className="px-5 py-8 text-center text-xs text-[#8b7e72]" data-testid="empty-timeline">لا توجد أحداث مسجلة بعد.</div>}</section>
        <div className="flex items-start gap-3 border border-[#e8deca] bg-[#faf6eb] p-4 text-[10px] leading-5 text-[#786548]"><ShieldCheck size={15} className="mt-0.5 shrink-0" /><p>تُحفظ التغييرات في سجل المعاملة. الإجراءات المتاحة تعتمد على دور المستخدم وحالة المعاملة.</p></div>
      </aside>
    </div>
    {actionError && <div className="mt-5 border border-red-200 bg-red-50 p-4 text-xs text-red-800" role="alert" data-testid="error-transaction-action">{actionError}</div>}
    {isBusy && <div className="fixed bottom-4 left-4 z-40 border border-[#dcccae] bg-[#fffdf8] px-4 py-3 text-xs text-[#765c31] shadow-md" role="status" data-testid="mutation-progress">جارٍ حفظ الإجراء...</div>}
  </div>;
}

function AdminUsersPage({ user }: { user: UserProfile }) {
  const queryClient = useQueryClient();
  const usersQuery = useListUsers({ query: { enabled: user.role === 'super_admin', queryKey: getListUsersQueryKey() } });
  const updateRole = useUpdateUserRole();
  const [roles, setRoles] = useState<Record<string, UserRole>>({});
  const [departments, setDepartments] = useState<Record<string, string>>({});
  const [feedback, setFeedback] = useState('');
  async function saveRole(profile: UserProfile) {
    const role = roles[profile.userId] ?? profile.role;
    const department = departments[profile.userId] ?? profile.department ?? '';
    try {
      await updateRole.mutateAsync({ userId: profile.userId, data: { role, department: department || null } });
      await queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
      setFeedback(`تم تحديث صلاحية ${profile.displayName}.`);
    } catch (error) { setFeedback(errorMessage(error)); }
  }
  const rolesList: UserRole[] = ['pending', 'super_admin', 'prosecutor', 'employee', 'department_manager'];
  if (user.role !== 'super_admin') return <div className="border border-[#ead7d4] bg-[#fff8f6] p-8 text-center" data-testid="admin-forbidden"><ShieldAlert className="mx-auto text-[#9b3937]" /><h1 className="mt-3 font-bold">لا تملك صلاحية إدارة المستخدمين</h1><p className="mt-2 text-sm text-[#806d66]">هذه الصفحة متاحة لمدير النظام فقط.</p><Link href="/dashboard" className="mt-5 inline-block text-xs font-semibold text-[#58141E] underline" data-testid="link-admin-back">العودة للوحة المتابعة</Link></div>;
  return <div className="rise-in">
    <PageHeading eyebrow="التحكم بالوصول" title="إدارة المستخدمين" detail="تعيين الدور الوظيفي والقسم للمستخدمين المسجلين." />
    {feedback && <div className="mb-4 border border-[#d9c9a8] bg-[#faf5e9] p-3 text-xs text-[#715b36]" role="status" data-testid="status-user-update">{feedback}</div>}
    {usersQuery.isLoading ? <LoadingPanel title="جارٍ تحميل المستخدمين" /> : usersQuery.isError ? <ErrorPanel error={usersQuery.error} retry={() => void usersQuery.refetch()} /> : !usersQuery.data?.length ? <div className="border border-dashed border-[#d8cdbd] bg-[#faf8f3] px-6 py-14 text-center" data-testid="empty-users"><Users size={22} className="mx-auto text-[#a18a63]" /><h2 className="mt-4 text-sm font-bold">لا يوجد مستخدمون لعرضهم</h2><p className="mt-2 text-xs text-[#8c8074]">ستظهر الحسابات عند تسجيلها في النظام.</p></div> :
      <div className="overflow-hidden border border-[#e5ddd1] bg-[#fffdf8]">
        <div className="grid grid-cols-[minmax(140px,1fr)_minmax(120px,.8fr)] gap-3 border-b border-[#e8e0d5] bg-[#f7f3eb] px-5 py-3 text-[10px] font-semibold text-[#786c60] md:grid-cols-[minmax(140px,1fr)_minmax(120px,.7fr)_minmax(150px,.8fr)_100px]"><span>المستخدم</span><span>الدور الحالي</span><span className="hidden md:block">القسم</span><span className="hidden md:block">الإجراء</span></div>
        <div className="divide-y divide-[#eee8df]">{usersQuery.data.map((profile) => <article key={profile.userId} className="grid gap-3 px-4 py-4 md:grid-cols-[minmax(140px,1fr)_minmax(120px,.7fr)_minmax(150px,.8fr)_100px] md:items-center md:gap-3 md:px-5" data-testid={`row-user-${profile.userId}`}>
          <div className="flex min-w-0 items-center gap-3"><span className="grid h-9 w-9 shrink-0 place-items-center border border-[#eadfcf] bg-[#f6f1e8] text-xs font-bold text-[#765832]">{profile.displayName.slice(0, 1) || 'م'}</span><div className="min-w-0"><p className="truncate text-xs font-semibold" data-testid={`user-name-${profile.userId}`}>{profile.displayName}</p><p className="mt-1 truncate font-mono text-[9px] text-[#9a8e82]">{profile.userId}</p></div></div>
          <div className="text-[10px] text-[#73675c]">{roleText[profile.role]}</div>
          <div className="grid gap-2 sm:grid-cols-2 md:contents"><select value={roles[profile.userId] ?? profile.role} onChange={(e) => setRoles((prev) => ({ ...prev, [profile.userId]: e.target.value as UserRole }))} className="h-9 border border-[#e1d8cc] bg-[#fffdf8] px-2 text-xs outline-none focus:border-[#a88b5a]" aria-label={`دور ${profile.displayName}`} data-testid={`select-role-${profile.userId}`}>{rolesList.map((role) => <option key={role} value={role}>{roleText[role]}</option>)}</select><input value={departments[profile.userId] ?? profile.department ?? ''} onChange={(e) => setDepartments((prev) => ({ ...prev, [profile.userId]: e.target.value }))} placeholder="القسم (اختياري)" className="h-9 border border-[#e1d8cc] px-2 text-xs outline-none focus:border-[#a88b5a]" aria-label={`قسم ${profile.displayName}`} data-testid={`input-department-${profile.userId}`} /></div>
          <button disabled={updateRole.isPending} onClick={() => void saveRole(profile)} className="h-9 bg-[#58141E] px-3 text-[10px] font-semibold text-white hover:bg-[#4A0E17] disabled:opacity-50" data-testid={`button-save-role-${profile.userId}`}>{updateRole.isPending ? 'جارٍ الحفظ' : 'حفظ الصلاحية'}</button>
        </article>)}</div>
      </div>}
  </div>;
}

function AccessPending({ user }: { user: UserProfile }) {
  return (
    <div className="mx-auto max-w-xl border border-[#e7d7b5] bg-[#fffdf8] px-7 py-12 text-center" data-testid="pending-access-state">
      <div className="mx-auto grid h-14 w-14 place-items-center border border-[#e7d7b5] bg-[#faf5e9] text-[#94702f]"><Clock3 size={22} /></div>
      <p className="mt-6 text-[10px] font-bold tracking-[.13em] text-[#9c7941]">صلاحية قيد المراجعة</p>
      <h1 className="mt-2 text-2xl font-bold text-[#4A0E17]">حسابك بانتظار تفعيل الوصول</h1>
      <p className="mt-3 text-sm leading-7 text-[#827569]">مرحباً {user.displayName}، تم تسجيل حسابك بنجاح. ستصبح مساحة العمل متاحة بعد تعيين دورك من قبل مدير النظام.</p>
      <div className="mt-6 border-t border-[#eee7dc] pt-4 text-xs text-[#8b7e72]">الحالة الحالية: <span className="font-semibold text-[#946b2c]">{roleText.pending}</span></div>
      <div className="mt-5 rounded-sm bg-[#f7f3eb] p-4 text-right">
        <p className="text-[11px] font-semibold text-[#4A0E17]">معرّف الحساب لتهيئة أول مدير للنظام</p>
        <code className="mt-2 block select-all break-all font-mono text-[10px] text-[#786c60]" dir="ltr" data-testid="text-account-id">{user.userId}</code>
        <p className="mt-2 text-[10px] leading-6 text-[#827569]">إذا كان هذا أول حساب مدير، أضف المعرّف إلى قائمة المسؤولين الأولية في إعدادات المشروع ثم حدّث حالة الصلاحية.</p>
      </div>
    </div>
  );
}

function ProtectedRoutes() {
  const auth = useAuth();
  const queryClientForAccess = useQueryClient();
  const userQuery = useGetCurrentUser({ query: { enabled: Boolean(auth.isSignedIn), queryKey: getGetCurrentUserQueryKey(), retry: false } });
  if (!auth.isLoaded) return <div className="min-h-[100dvh] bg-[#f5f2eb] p-8"><LoadingPanel /></div>;
  if (!auth.isSignedIn) return <Redirect to="/" />;
  if (userQuery.isLoading) return <div className="min-h-[100dvh] bg-[#f5f2eb] p-8"><LoadingPanel title="جارٍ التحقق من الصلاحيات" /></div>;
  if (userQuery.isError || !userQuery.data) return <div className="mx-auto mt-20 max-w-lg px-5"><ErrorPanel error={userQuery.error ?? new Error('تعذر تحميل ملف المستخدم.')} retry={() => void userQuery.refetch()} /></div>;
  const user = userQuery.data;
  if (user.role === 'pending') return <main className="min-h-[100dvh] bg-[#f5f2eb] px-4 py-14" dir="rtl"><div className="mx-auto mb-8 flex max-w-xl justify-center"><Brand /></div><AccessPending user={user} /><div className="mt-6 text-center"><button className="text-xs text-[#786a60] underline" onClick={() => void queryClientForAccess.invalidateQueries({ queryKey: getGetCurrentUserQueryKey() })} data-testid="button-refresh-access">تحديث حالة الصلاحية</button></div></main>;
  return <AppShell user={user}><Switch>
    <Route path="/dashboard"><DashboardPage user={user} /></Route>
    <Route path="/transactions"><TransactionsPage /></Route>
    <Route path="/transactions/new"><NewTransactionPage /></Route>
    <Route path="/transactions/:id">{(params) => <TransactionDetailPage user={user} id={params.id} />}</Route>
    <Route path="/admin/users"><AdminUsersPage user={user} /></Route>
    <Route><NotFound /></Route>
  </Switch></AppShell>;
}

function HomeRedirect() {
  return <><Show when="signed-in"><Redirect to="/dashboard" /></Show><Show when="signed-out"><HomePage /></Show></>;
}

function Router() {
  return <Switch>
    <Route path="/"><HomeRedirect /></Route>
    <Route path="/sign-in/*?"><SignInPage /></Route>
    <Route path="/sign-up/*?"><SignUpPage /></Route>
    <Route><ProtectedRoutes /></Route>
  </Switch>;
}

function App() {
  if (!clerkPubKey) throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY');
  return <QueryClientProvider client={queryClient}>
    <WouterRouter base={basePath}><ClerkProviderWithRoutes /></WouterRouter>
  </QueryClientProvider>;
}

export default App;
