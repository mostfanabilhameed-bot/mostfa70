import {
  RequestUploadUrlBody,
  RequestUploadUrlResponse,
} from "@workspace/api-zod";
import { db, pendingUploadsTable } from "@workspace/db";
import { Router, type IRouter } from "express";
import {
  requireApplicationRole,
  requireClerkAuthentication,
} from "../lib/authz";
import { ObjectStorageService } from "../lib/objectStorage";

const router: IRouter = Router();
const objectStorage = new ObjectStorageService();
const uploadRoles = ["employee", "super_admin"] as const;

router.post(
  "/storage/uploads/request-url",
  requireClerkAuthentication,
  async (req, res): Promise<void> => {
    const user = await requireApplicationRole(req, res, uploadRoles);
    if (!user) return;
    const parsed = RequestUploadUrlBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }
    if (/[/\\\u0000-\u001f\u007f]/.test(parsed.data.name)) {
      res.status(400).json({ error: "اسم الملف غير صالح." });
      return;
    }

    try {
      const uploadURL = await objectStorage.getObjectEntityUploadURL();
      const objectPath = objectStorage.normalizeObjectEntityPath(uploadURL);
      await db.insert(pendingUploadsTable).values({
        objectPath,
        ownerUserId: user.clerkUserId,
        fileName: parsed.data.name,
        contentType: parsed.data.contentType,
        size: parsed.data.size,
      });
      res.json(
        RequestUploadUrlResponse.parse({
          uploadURL,
          objectPath,
          metadata: parsed.data,
        }),
      );
    } catch (error) {
      req.log.error({ err: error }, "Could not create private upload URL");
      res.status(500).json({ error: "تعذر تجهيز رفع المستند." });
    }
  },
);

export default router;
