import {
  ListUsersResponse,
  UpdateUserRoleBody,
  UpdateUserRoleParams,
  UpdateUserRoleResponse,
} from "@workspace/api-zod";
import {
  auditLogsTable,
  db,
  userProfilesTable,
} from "@workspace/db";
import { desc, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  requireApplicationRole,
  requireClerkAuthentication,
} from "../lib/authz";

const router: IRouter = Router();
const superAdminOnly = ["super_admin"] as const;

router.use(requireClerkAuthentication);

router.get("/admin/users", async (req, res): Promise<void> => {
  const actor = await requireApplicationRole(req, res, superAdminOnly);
  if (!actor) return;
  const users = await db
    .select()
    .from(userProfilesTable)
    .orderBy(desc(userProfilesTable.createdAt));
  res.json(
    ListUsersResponse.parse(
      users.map((user) => ({
        userId: user.clerkUserId,
        displayName: user.displayName,
        role: user.role,
        department: user.department,
        createdAt: user.createdAt,
      })),
    ),
  );
});

router.put("/admin/users/:userId/role", async (req, res): Promise<void> => {
  const actor = await requireApplicationRole(req, res, superAdminOnly);
  if (!actor) return;
  const params = UpdateUserRoleParams.safeParse(req.params);
  const body = UpdateUserRoleBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  if (
    params.data.userId === actor.clerkUserId &&
    body.data.role !== "super_admin"
  ) {
    res.status(409).json({ error: "لا يمكن للمسؤول إزالة صلاحية نفسه." });
    return;
  }

  const targetUser = await getApplicationUserForId(params.data.userId);
  if (!targetUser) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  const update: {
    role: typeof body.data.role;
    department?: string | null;
    updatedAt: Date;
  } = {
    role: body.data.role,
    updatedAt: new Date(),
  };
  if (body.data.department !== undefined) {
    update.department = body.data.department;
  }

  const result = await db.transaction(async (tx) => {
    const [updated] = await tx
      .update(userProfilesTable)
      .set(update)
      .where(eq(userProfilesTable.clerkUserId, params.data.userId))
      .returning();
    if (!updated) return null;
    await tx.insert(auditLogsTable).values({
      actorUserId: actor.clerkUserId,
      action: "user_role_updated",
      entityType: "user_profile",
      entityId: updated.clerkUserId,
      previousValue: JSON.stringify({
        role: targetUser.role,
        department: targetUser.department,
      }),
      newValue: JSON.stringify({
        role: updated.role,
        department: updated.department,
      }),
    });
    return updated;
  });
  if (!result) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  res.json(
    UpdateUserRoleResponse.parse({
      userId: result.clerkUserId,
      displayName: result.displayName,
      role: result.role,
      department: result.department,
      createdAt: result.createdAt,
    }),
  );
});

async function getApplicationUserForId(clerkUserId: string) {
  const [user] = await db
    .select()
    .from(userProfilesTable)
    .where(eq(userProfilesTable.clerkUserId, clerkUserId))
    .limit(1);
  return user ?? null;
}

export default router;
