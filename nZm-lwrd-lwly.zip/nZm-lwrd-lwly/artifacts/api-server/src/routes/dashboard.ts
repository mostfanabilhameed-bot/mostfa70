import { GetDashboardSummaryResponse } from "@workspace/api-zod";
import {
  db,
  inboundTransactionsTable,
  timelineEventsTable,
} from "@workspace/db";
import { and, count, desc, eq, gte } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  getApplicationUser,
  requireClerkAuthentication,
} from "../lib/authz";
import { transactionScopeCondition } from "../lib/inbound-transactions";

const router: IRouter = Router();

router.get(
  "/dashboard/summary",
  requireClerkAuthentication,
  async (req, res): Promise<void> => {
    const user = await getApplicationUser(req);
    if (!user || user.role === "pending") {
      res.status(403).json({ error: "Forbidden" });
      return;
    }
    const scope = transactionScopeCondition(user);
    const monthStart = new Date();
    monthStart.setDate(1);
    monthStart.setHours(0, 0, 0, 0);

    const [statusCounts, referredCount, recentRows] = await Promise.all([
      db
        .select({
          status: inboundTransactionsTable.status,
          total: count(),
        })
        .from(inboundTransactionsTable)
        .where(scope)
        .groupBy(inboundTransactionsTable.status),
      db
        .select({ total: count() })
        .from(timelineEventsTable)
        .innerJoin(
          inboundTransactionsTable,
          eq(timelineEventsTable.transactionId, inboundTransactionsTable.id),
        )
        .where(
          and(
            eq(timelineEventsTable.eventType, "transaction_dispatched"),
            gte(timelineEventsTable.createdAt, monthStart),
            scope,
          ),
        ),
      db
        .select({
          id: timelineEventsTable.id,
          eventType: timelineEventsTable.eventType,
          description: timelineEventsTable.description,
          actorName: timelineEventsTable.actorName,
          previousValue: timelineEventsTable.previousValue,
          newValue: timelineEventsTable.newValue,
          createdAt: timelineEventsTable.createdAt,
        })
        .from(timelineEventsTable)
        .innerJoin(
          inboundTransactionsTable,
          eq(timelineEventsTable.transactionId, inboundTransactionsTable.id),
        )
        .where(scope)
        .orderBy(desc(timelineEventsTable.createdAt))
        .limit(8),
    ]);
    const counts = new Map(
      statusCounts.map((item) => [item.status, Number(item.total)]),
    );
    res.json(
      GetDashboardSummaryResponse.parse({
        totalTransactions: [...counts.values()].reduce(
          (total, value) => total + value,
          0,
        ),
        awaitingDirection: counts.get("awaiting_direction") ?? 0,
        awaitingTranscription: counts.get("awaiting_transcription") ?? 0,
        awaitingReferral: counts.get("awaiting_referral") ?? 0,
        referredThisMonth: Number(referredCount[0]?.total ?? 0),
        recentActivity: recentRows,
      }),
    );
  },
);

export default router;
