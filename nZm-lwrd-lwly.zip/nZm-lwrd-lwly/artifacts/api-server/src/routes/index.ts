import { Router, type IRouter } from "express";
import adminRouter from "./admin";
import dashboardRouter from "./dashboard";
import healthRouter from "./health";
import identityRouter from "./identity";
import storageRouter from "./storage";
import transactionsRouter from "./transactions";

const router: IRouter = Router();

router.use(healthRouter);
router.use(identityRouter);
router.use(dashboardRouter);
router.use(transactionsRouter);
router.use(adminRouter);
router.use(storageRouter);

export default router;
