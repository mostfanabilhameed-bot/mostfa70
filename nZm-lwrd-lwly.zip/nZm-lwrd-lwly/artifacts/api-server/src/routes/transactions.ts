import {
  ApproveDirectiveBody,
  ApproveDirectiveParams,
  ApproveDirectiveResponse,
  CreateTransactionBody,
  CreateTransactionResponse,
  DispatchTransactionParams,
  DispatchTransactionResponse,
  GetTransactionParams,
  GetTransactionResponse,
  GetTransactionTimelineParams,
  GetTransactionTimelineResponse,
  ListTransactionsQueryParams,
  ListTransactionsResponse,
  RejectTransactionBody,
  RejectTransactionParams,
  RejectTransactionResponse,
  SaveDirectiveDraftBody,
  SaveDirectiveDraftParams,
  SaveDirectiveDraftResponse,
  SaveReferralBody,
  SaveReferralParams,
  SaveReferralResponse,
  SubmitTransactionParams,
  SubmitTransactionResponse,
} from "@workspace/api-zod";
import {
  annualSequencesTable,
  db,
  inboundTransactionsTable,
  pendingUploadsTable,
  timelineEventsTable,
  type TransactionStatus,
} from "@workspace/db";
import {
  and,
  count,
  desc,
  eq,
  ilike,
  isNull,
  or,
  sql,
  type SQL,
} from "drizzle-orm";
import { randomUUID } from "node:crypto";
import { Router, type IRouter } from "express";
import {
  getApplicationUser,
  requireApplicationRole,
  requireClerkAuthentication,
  type ApplicationUser,
} from "../lib/authz";
import {
  findVisibleTransaction,
  toTransactionResponse,
  transactionScopeCondition,
  UploadValidationError,
  verifyPendingUpload,
} from "../lib/inbound-transactions";
import { ObjectStorageService } from "../lib/objectStorage";

const router: IRouter = Router();
const objectStorage = new ObjectStorageService();
const staffRoles = ["employee", "super_admin"] as const;
const prosecutorRoles = ["prosecutor", "super_admin"] as const;

router.use(requireClerkAuthentication);

function buildListFilters(
  user: ApplicationUser,
  query: {
    query?: string;
    status?: TransactionStatus;
    year?: number;
    confidentiality?: "normal" | "confidential" | "secret";
  },
): SQL[] {
  const clauses: SQL[] = [];
  const scope = transactionScopeCondition(user);
  if (scope) clauses.push(scope);
  if (query.query?.trim()) {
    const term = `%${query.query.trim()}%`;
    const search = or(
      ilike(inboundTransactionsTable.subject, term),
      ilike(inboundTransactionsTable.senderName, term),
      ilike(inboundTransactionsTable.source, term),
    );
    if (search) clauses.push(search);
  }
  if (query.status) {
    clauses.push(eq(inboundTransactionsTable.status, query.status));
  }
  if (query.year) clauses.push(eq(inboundTransactionsTable.year, query.year));
  if (query.confidentiality) {
    clauses.push(
      eq(inboundTransactionsTable.confidentiality, query.confidentiality),
    );
  }
  return clauses;
}

router.get("/transactions", async (req, res): Promise<void> => {
  const user = await getApplicationUser(req);
  if (!user || user.role === "pending") {
    res.status(403).json({ error: "Forbidden" });
    return;
  }
  const parsed = ListTransactionsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { limit = 25, offset = 0 } = parsed.data;
  const filters = buildListFilters(user, parsed.data);
  const where = filters.length ? and(...filters) : undefined;
  const [items, totals] = await Promise.all([
    db
      .select()
      .from(inboundTransactionsTable)
      .where(where)
      .orderBy(desc(inboundTransactionsTable.registeredAt))
      .limit(limit)
      .offset(offset),
    db.select({ total: count() }).from(inboundTransactionsTable).where(where),
  ]);
  res.json(
    ListTransactionsResponse.parse({
      items: items.map(toTransactionResponse),
      total: totals[0]?.total ?? 0,
      limit,
      offset,
    }),
  );
});

router.post("/transactions", async (req, res): Promise<void> => {
  const user = await requireApplicationRole(req, res, staffRoles);
  if (!user) return;
  const parsed = CreateTransactionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const attachment = parsed.data.attachment;
  let verifiedAttachment: { contentType: string; sha256: string };
  try {
    verifiedAttachment = await verifyPendingUpload(user.clerkUserId, attachment);
  } catch (error) {
    if (error instanceof UploadValidationError) {
      res.status(error.statusCode).json({ error: error.message });
      return;
    }
    throw error;
  }

  const now = new Date();
  const year = now.getFullYear();
  const [sequence] = await db
    .insert(annualSequencesTable)
    .values({ year, lastNumber: 1 })
    .onConflictDoUpdate({
      target: annualSequencesTable.year,
      set: { lastNumber: sql`${annualSequencesTable.lastNumber} + 1` },
    })
    .returning({ number: annualSequencesTable.lastNumber });
  if (!sequence) {
    res.status(500).json({ error: "تعذر حجز رقم الوارد." });
    return;
  }

  const id = randomUUID();
  let created;
  try {
    created = await db.transaction(async (tx) => {
      const [claimedUpload] = await tx
        .update(pendingUploadsTable)
        .set({ claimedAt: now, transactionId: id })
        .where(
          and(
            eq(pendingUploadsTable.objectPath, attachment.objectPath),
            eq(pendingUploadsTable.ownerUserId, user.clerkUserId),
            isNull(pendingUploadsTable.claimedAt),
          ),
        )
        .returning({ objectPath: pendingUploadsTable.objectPath });
      if (!claimedUpload) {
        throw new UploadValidationError(
          "تم استخدام الملف مسبقاً أو انتهت صلاحيته.",
          409,
        );
      }

      const [transaction] = await tx
        .insert(inboundTransactionsTable)
        .values({
          id,
          inboundNumber: sequence.number,
          year,
          status: "registered",
          subject: parsed.data.subject.trim(),
          senderName: parsed.data.senderName.trim(),
          source: parsed.data.source.trim(),
          receivedDate: parsed.data.receivedDate.toISOString().slice(0, 10),
          confidentiality: parsed.data.confidentiality,
          urgency: parsed.data.urgency,
          notes: parsed.data.notes?.trim() || null,
          attachmentPath: attachment.objectPath,
          attachmentName: attachment.fileName,
          attachmentContentType: verifiedAttachment.contentType,
          attachmentSize: attachment.size,
          attachmentSha256: verifiedAttachment.sha256,
          createdBy: user.clerkUserId,
          createdByName: user.displayName,
          department: user.department,
          version: 1,
        })
        .returning();
      if (!transaction) throw new Error("Transaction insert did not return a row.");
      await tx.insert(timelineEventsTable).values({
        transactionId: transaction.id,
        eventType: "transaction_registered",
        description: `تم تسجيل الوارد رقم ${sequence.number} لعام ${year}.`,
        actorUserId: user.clerkUserId,
        actorName: user.displayName,
        newValue: "registered",
      });
      return transaction;
    });
  } catch (error) {
    if (error instanceof UploadValidationError) {
      res.status(error.statusCode).json({ error: error.message });
      return;
    }
    throw error;
  }

  res
    .status(201)
    .json(CreateTransactionResponse.parse(toTransactionResponse(created)));
});

router.get("/transactions/:id", async (req, res): Promise<void> => {
  const params = GetTransactionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const found = await findVisibleTransaction(req, params.data.id);
  if (!found) {
    res.status(404).json({ error: "Transaction not found" });
    return;
  }
  res.json(GetTransactionResponse.parse(toTransactionResponse(found.transaction)));
});

router.get("/transactions/:id/document", async (req, res): Promise<void> => {
  const params = GetTransactionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const found = await findVisibleTransaction(req, params.data.id);
  if (!found) {
    res.status(404).json({ error: "Document not found" });
    return;
  }

  let file;
  try {
    file = await objectStorage.getObjectEntityFile(
      found.transaction.attachmentPath,
    );
  } catch {
    res.status(404).json({ error: "Document not found" });
    return;
  }
  res.setHeader("Content-Type", found.transaction.attachmentContentType);
  res.setHeader("Content-Disposition", 'inline; filename="document"');
  res.setHeader("Cache-Control", "private, no-store");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Content-Length", String(found.transaction.attachmentSize));
  file
    .createReadStream()
    .on("error", (error) => {
      req.log.error({ err: error, transactionId: params.data.id }, "Document stream failed");
      if (!res.headersSent) res.status(404).end();
      else res.destroy(error);
    })
    .pipe(res);
});

router.post("/transactions/:id/submit", async (req, res): Promise<void> => {
  const user = await requireApplicationRole(req, res, staffRoles);
  if (!user) return;
  const params = SubmitTransactionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const found = await findVisibleTransaction(req, params.data.id);
  if (
    !found ||
    (user.role !== "super_admin" &&
      found.transaction.createdBy !== user.clerkUserId)
  ) {
    res.status(404).json({ error: "Transaction not found" });
    return;
  }
  const updated = await applyTransition(
    found.transaction.id,
    user,
    ["registered"],
    { status: "awaiting_direction" },
    "transaction_submitted",
    "أُحيلت المعاملة إلى قائمة التوجيه.",
  );
  if (!updated) {
    res.status(409).json({ error: "تعذر الإرسال بسبب تغير حالة المعاملة." });
    return;
  }
  res.json(SubmitTransactionResponse.parse(toTransactionResponse(updated)));
});

router.put("/transactions/:id/directive", async (req, res): Promise<void> => {
  const user = await requireApplicationRole(req, res, prosecutorRoles);
  if (!user) return;
  const params = SaveDirectiveDraftParams.safeParse(req.params);
  const body = SaveDirectiveDraftBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const found = await findVisibleTransaction(req, params.data.id);
  if (!found) {
    res.status(404).json({ error: "Transaction not found" });
    return;
  }
  const updated = await applyTransition(
    found.transaction.id,
    user,
    ["awaiting_direction", "in_review", "directive_draft"],
    { status: "directive_draft", directiveDraftText: body.data.text.trim() },
    "directive_draft_saved",
    "حُفظت مسودة التوجيه.",
    body.data.expectedVersion,
  );
  if (!updated) {
    res.status(409).json({ error: "تغيرت المعاملة؛ أعد تحميلها قبل الحفظ." });
    return;
  }
  res.json(SaveDirectiveDraftResponse.parse(toTransactionResponse(updated)));
});

router.post("/transactions/:id/approve", async (req, res): Promise<void> => {
  const user = await requireApplicationRole(req, res, prosecutorRoles);
  if (!user) return;
  const params = ApproveDirectiveParams.safeParse(req.params);
  const body = ApproveDirectiveBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const found = await findVisibleTransaction(req, params.data.id);
  if (!found) {
    res.status(404).json({ error: "Transaction not found" });
    return;
  }
  if (!found.transaction.directiveDraftText?.trim()) {
    res.status(409).json({ error: "لا توجد مسودة توجيه لاعتمادها." });
    return;
  }
  const updated = await applyTransition(
    found.transaction.id,
    user,
    ["directive_draft"],
    {
      status: "awaiting_transcription",
      directiveText: found.transaction.directiveDraftText,
    },
    "directive_approved",
    "اعتمد النائب العام التوجيه.",
    body.data.expectedVersion,
  );
  if (!updated) {
    res.status(409).json({ error: "تغيرت المعاملة؛ أعد تحميلها قبل الاعتماد." });
    return;
  }
  res.json(ApproveDirectiveResponse.parse(toTransactionResponse(updated)));
});

router.post("/transactions/:id/reject", async (req, res): Promise<void> => {
  const user = await requireApplicationRole(req, res, prosecutorRoles);
  if (!user) return;
  const params = RejectTransactionParams.safeParse(req.params);
  const body = RejectTransactionBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const found = await findVisibleTransaction(req, params.data.id);
  if (!found) {
    res.status(404).json({ error: "Transaction not found" });
    return;
  }
  const updated = await applyTransition(
    found.transaction.id,
    user,
    ["awaiting_direction", "in_review", "directive_draft"],
    { status: "rejected", rejectionReason: body.data.reason.trim() },
    "transaction_rejected",
    "رُفضت المعاملة مع تسجيل سبب الرفض.",
  );
  if (!updated) {
    res.status(409).json({ error: "لا يمكن رفض المعاملة في حالتها الحالية." });
    return;
  }
  res.json(RejectTransactionResponse.parse(toTransactionResponse(updated)));
});

router.put("/transactions/:id/referral", async (req, res): Promise<void> => {
  const user = await requireApplicationRole(req, res, staffRoles);
  if (!user) return;
  const params = SaveReferralParams.safeParse(req.params);
  const body = SaveReferralBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const found = await findVisibleTransaction(req, params.data.id);
  if (
    !found ||
    (user.role !== "super_admin" &&
      found.transaction.createdBy !== user.clerkUserId)
  ) {
    res.status(404).json({ error: "Transaction not found" });
    return;
  }
  const updated = await applyTransition(
    found.transaction.id,
    user,
    ["awaiting_transcription", "directed"],
    {
      status: "awaiting_referral",
      transcription: body.data.transcription.trim(),
      referralDestination: body.data.destination.trim(),
    },
    "referral_details_saved",
    "سُجل تفريغ التوجيه وجهة الإحالة.",
    body.data.expectedVersion,
  );
  if (!updated) {
    res.status(409).json({ error: "تغيرت المعاملة؛ أعد تحميلها قبل الحفظ." });
    return;
  }
  res.json(SaveReferralResponse.parse(toTransactionResponse(updated)));
});

router.post("/transactions/:id/dispatch", async (req, res): Promise<void> => {
  const user = await requireApplicationRole(req, res, staffRoles);
  if (!user) return;
  const params = DispatchTransactionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const found = await findVisibleTransaction(req, params.data.id);
  if (
    !found ||
    (user.role !== "super_admin" &&
      found.transaction.createdBy !== user.clerkUserId)
  ) {
    res.status(404).json({ error: "Transaction not found" });
    return;
  }
  const updated = await applyTransition(
    found.transaction.id,
    user,
    ["awaiting_referral"],
    { status: "referred" },
    "transaction_dispatched",
    "سُجل ترحيل المعاملة إلى جهة الإحالة.",
  );
  if (!updated) {
    res.status(409).json({ error: "لا يمكن ترحيل المعاملة في حالتها الحالية." });
    return;
  }
  res.json(DispatchTransactionResponse.parse(toTransactionResponse(updated)));
});

router.get("/transactions/:id/timeline", async (req, res): Promise<void> => {
  const params = GetTransactionTimelineParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const found = await findVisibleTransaction(req, params.data.id);
  if (!found) {
    res.status(404).json({ error: "Transaction not found" });
    return;
  }
  const events = await db
    .select({
      id: timelineEventsTable.id,
      eventType: timelineEventsTable.eventType,
      description: timelineEventsTable.description,
      actorName: timelineEventsTable.actorName,
      previousValue: timelineEventsTable.previousValue,
      newValue: timelineEventsTable.newValue,
      createdAt: timelineEventsTable.createdAt,
    })
    .from(timelineEventsTable)
    .where(eq(timelineEventsTable.transactionId, found.transaction.id))
    .orderBy(desc(timelineEventsTable.createdAt));
  res.json(GetTransactionTimelineResponse.parse(events));
});

async function applyTransition(
  id: string,
  actor: ApplicationUser,
  allowedStatuses: TransactionStatus[],
  changes: Partial<typeof inboundTransactionsTable.$inferInsert>,
  eventType: string,
  description: string,
  expectedVersion?: number,
) {
  return db.transaction(async (tx) => {
    const [current] = await tx
      .select()
      .from(inboundTransactionsTable)
      .where(eq(inboundTransactionsTable.id, id))
      .for("update")
      .limit(1);
    if (
      !current ||
      !allowedStatuses.includes(current.status) ||
      (expectedVersion !== undefined && current.version !== expectedVersion)
    ) {
      return null;
    }
    const [updated] = await tx
      .update(inboundTransactionsTable)
      .set({
        ...changes,
        version: current.version + 1,
        updatedAt: new Date(),
      })
      .where(eq(inboundTransactionsTable.id, id))
      .returning();
    if (!updated) return null;
    await tx.insert(timelineEventsTable).values({
      transactionId: id,
      eventType,
      description,
      actorUserId: actor.clerkUserId,
      actorName: actor.displayName,
      previousValue: current.status,
      newValue: updated.status,
    });
    return updated;
  });
}

export default router;
