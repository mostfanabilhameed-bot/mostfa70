import { GetCurrentUserResponse } from "@workspace/api-zod";
import { Router, type IRouter } from "express";
import {
  getApplicationUser,
  requireClerkAuthentication,
} from "../lib/authz";

const router: IRouter = Router();

router.get("/me", requireClerkAuthentication, async (req, res): Promise<void> => {
  const user = await getApplicationUser(req);
  if (!user) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  res.json(
    GetCurrentUserResponse.parse({
      userId: user.clerkUserId,
      displayName: user.displayName,
      role: user.role,
      department: user.department,
      createdAt: user.createdAt,
    }),
  );
});

export default router;
