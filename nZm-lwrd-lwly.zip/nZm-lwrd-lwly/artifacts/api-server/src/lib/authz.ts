import { getAuth } from "@clerk/express";
import { auditLogsTable, db, userProfilesTable } from "@workspace/db";
import { and, eq } from "drizzle-orm";
import type { Request, RequestHandler, Response } from "express";

export type ApplicationUser = typeof userProfilesTable.$inferSelect;

export const requireClerkAuthentication: RequestHandler = (
  req,
  res,
  next,
): void => {
  if (!getAuth(req).userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  next();
};

function displayNameFromClaims(req: Request, fallback: string): string {
  const claims = getAuth(req).sessionClaims as Record<string, unknown> | null;
  const firstName = claims?.first_name;
  const lastName = claims?.last_name;
  const combined = [firstName, lastName]
    .filter(
      (part): part is string =>
        typeof part === "string" && part.trim().length > 0,
    )
    .join(" ")
    .trim();
  if (combined) return combined;
  for (const value of [claims?.name, claims?.email]) {
    if (typeof value === "string" && value.trim()) return value.trim();
  }
  return fallback;
}

export async function getApplicationUser(
  req: Request,
): Promise<ApplicationUser | null> {
  const auth = getAuth(req);
  const clerkUserId = auth.userId;
  if (!clerkUserId) return null;
  const configuredAdmins = new Set(
    (process.env.INITIAL_SUPER_ADMIN_USER_IDS ?? "")
      .split(",")
      .map((id) => id.trim())
      .filter(Boolean),
  );

  const [existing] = await db
    .select()
    .from(userProfilesTable)
    .where(eq(userProfilesTable.clerkUserId, clerkUserId))
    .limit(1);
  if (existing) {
    if (existing.role !== "pending" || !configuredAdmins.has(clerkUserId)) {
      return existing;
    }
    const [promoted] = await db
      .update(userProfilesTable)
      .set({ role: "super_admin", updatedAt: new Date() })
      .where(
        and(
          eq(userProfilesTable.clerkUserId, clerkUserId),
          eq(userProfilesTable.role, "pending"),
        ),
      )
      .returning();
    if (!promoted) return existing;
    await db.insert(auditLogsTable).values({
      actorUserId: "system:bootstrap",
      action: "initial_super_admin_granted",
      entityType: "user_profile",
      entityId: clerkUserId,
      previousValue: "pending",
      newValue: "super_admin",
    });
    return promoted;
  }

  const [created] = await db
    .insert(userProfilesTable)
    .values({
      clerkUserId,
      displayName: displayNameFromClaims(req, clerkUserId),
      role: configuredAdmins.has(clerkUserId) ? "super_admin" : "pending",
    })
    .onConflictDoNothing({
      target: userProfilesTable.clerkUserId,
    })
    .returning();
  if (created) {
    if (created.role === "super_admin") {
      await db.insert(auditLogsTable).values({
        actorUserId: "system:bootstrap",
        action: "initial_super_admin_granted",
        entityType: "user_profile",
        entityId: clerkUserId,
        previousValue: null,
        newValue: "super_admin",
      });
    }
    return created;
  }

  const [raced] = await db
    .select()
    .from(userProfilesTable)
    .where(eq(userProfilesTable.clerkUserId, clerkUserId))
    .limit(1);
  return raced ?? null;
}

export async function requireApplicationRole(
  req: Request,
  res: Response,
  roles: readonly ApplicationUser["role"][],
): Promise<ApplicationUser | null> {
  const user = await getApplicationUser(req);
  if (!user) {
    res.status(401).json({ error: "Unauthorized" });
    return null;
  }
  if (!roles.includes(user.role)) {
    res.status(403).json({ error: "Forbidden" });
    return null;
  }
  return user;
}

export function getClerkUserId(req: Request): string | null {
  return getAuth(req).userId ?? null;
}

