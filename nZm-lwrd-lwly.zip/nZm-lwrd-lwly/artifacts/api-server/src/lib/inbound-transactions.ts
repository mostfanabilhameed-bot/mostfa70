import {
  db,
  inboundTransactionsTable,
  pendingUploadsTable,
  type InboundTransaction,
  type UserProfile,
} from "@workspace/db";
import { and, eq, gte, isNull, ne, sql, type SQL } from "drizzle-orm";
import type { Request } from "express";
import { createHash } from "node:crypto";
import { getApplicationUser } from "./authz";
import { ObjectStorageService } from "./objectStorage";

const objectStorage = new ObjectStorageService();

export class UploadValidationError extends Error {
  constructor(
    message: string,
    public readonly statusCode = 400,
  ) {
    super(message);
    this.name = "UploadValidationError";
  }
}

export function transactionScopeCondition(user: UserProfile): SQL | undefined {
  if (user.role === "super_admin" || user.role === "prosecutor") return undefined;
  if (user.role === "employee") {
    return and(
      eq(inboundTransactionsTable.createdBy, user.clerkUserId),
      ne(inboundTransactionsTable.confidentiality, "secret"),
    );
  }
  if (user.role === "department_manager" && user.department) {
    return and(
      eq(inboundTransactionsTable.department, user.department),
      ne(inboundTransactionsTable.confidentiality, "secret"),
    );
  }
  return sql`false`;
}

export function canAccessTransaction(
  user: UserProfile,
  transaction: InboundTransaction,
): boolean {
  if (transaction.confidentiality === "secret") {
    return user.role === "super_admin" || user.role === "prosecutor";
  }
  if (user.role === "super_admin" || user.role === "prosecutor") return true;
  if (user.role === "employee") {
    return transaction.createdBy === user.clerkUserId;
  }
  return (
    user.role === "department_manager" &&
    Boolean(user.department) &&
    transaction.department === user.department
  );
}

export async function findVisibleTransaction(
  req: Request,
  id: string,
): Promise<{ user: UserProfile; transaction: InboundTransaction } | null> {
  const user = await getApplicationUser(req);
  if (!user || user.role === "pending") return null;
  const [transaction] = await db
    .select()
    .from(inboundTransactionsTable)
    .where(eq(inboundTransactionsTable.id, id))
    .limit(1);
  if (!transaction || !canAccessTransaction(user, transaction)) return null;
  return { user, transaction };
}

export function toTransactionResponse(transaction: InboundTransaction) {
  return {
    id: transaction.id,
    inboundNumber: transaction.inboundNumber,
    year: transaction.year,
    status: transaction.status,
    subject: transaction.subject,
    senderName: transaction.senderName,
    source: transaction.source,
    receivedDate: transaction.receivedDate,
    registeredAt: transaction.registeredAt,
    confidentiality: transaction.confidentiality,
    urgency: transaction.urgency,
    notes: transaction.notes,
    attachment: {
      objectPath: transaction.attachmentPath,
      fileName: transaction.attachmentName,
      contentType: transaction.attachmentContentType,
      size: transaction.attachmentSize,
      sha256: transaction.attachmentSha256,
    },
    directiveText: transaction.directiveText,
    directiveDraftText: transaction.directiveDraftText,
    rejectionReason: transaction.rejectionReason,
    transcription: transaction.transcription,
    referralDestination: transaction.referralDestination,
    department: transaction.department,
    createdBy: transaction.createdBy,
    createdByName: transaction.createdByName,
    version: transaction.version,
  };
}

export async function verifyPendingUpload(
  userId: string,
  attachment: {
    objectPath: string;
    fileName: string;
    contentType: string;
    size: number;
    sha256: string;
  },
): Promise<{ contentType: string; sha256: string }> {
  const cutoff = new Date(Date.now() - 60 * 60 * 1000);
  const [pending] = await db
    .select()
    .from(pendingUploadsTable)
    .where(
      and(
        eq(pendingUploadsTable.objectPath, attachment.objectPath),
        eq(pendingUploadsTable.ownerUserId, userId),
        isNull(pendingUploadsTable.claimedAt),
        gte(pendingUploadsTable.createdAt, cutoff),
      ),
    )
    .limit(1);

  if (
    !pending ||
    pending.fileName !== attachment.fileName ||
    pending.contentType !== attachment.contentType ||
    pending.size !== attachment.size
  ) {
    throw new UploadValidationError("ملف الرفع غير صالح أو انتهت صلاحيته.");
  }
  if (!/^[a-f0-9]{64}$/i.test(attachment.sha256)) {
    throw new UploadValidationError("بصمة الملف غير صالحة.");
  }

  let file;
  try {
    file = await objectStorage.getObjectEntityFile(attachment.objectPath);
  } catch {
    throw new UploadValidationError("تعذر العثور على الملف المرفوع.", 404);
  }
  const [bytes] = await file.download();
  if (bytes.byteLength !== pending.size || bytes.byteLength > 15 * 1024 * 1024) {
    throw new UploadValidationError("حجم الملف الفعلي لا يطابق الحجم المعلن.");
  }

  const contentType = detectDocumentType(bytes);
  if (!contentType || contentType !== pending.contentType) {
    throw new UploadValidationError("نوع محتوى الملف لا يطابق الصيغة المسموح بها.");
  }
  const sha256 = createHash("sha256").update(bytes).digest("hex");
  if (sha256.toLowerCase() !== attachment.sha256.toLowerCase()) {
    throw new UploadValidationError("فشلت مطابقة بصمة الملف.");
  }
  return { contentType, sha256 };
}

function detectDocumentType(bytes: Buffer): string | null {
  if (bytes.length >= 5 && bytes.subarray(0, 5).toString("ascii") === "%PDF-") {
    return "application/pdf";
  }
  if (
    bytes.length >= 3 &&
    bytes[0] === 0xff &&
    bytes[1] === 0xd8 &&
    bytes[2] === 0xff
  ) {
    return "image/jpeg";
  }
  const pngSignature = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  if (bytes.length >= 8 && bytes.subarray(0, 8).equals(pngSignature)) {
    return "image/png";
  }
  return null;
}
